import React from 'react';
import Index from './Components/Index';
import EngineeredExcellence from './Components/EngineeredExcellence';
import MernSolution from './Components/MernSolution';
import TransformingBusiness from './Components/TransformingBusiness';
import Result from './Components/Result';
import EngineerMethodology from './Components/EngineerMethodology';
import Technical from './Components/Technical';
import CommonQuestion from './Components/CommonQuestion';
import Digital from './Components/Digital';
import Commitment from './Components/Commitment';
import DigitalFuture from './Components/DigitalFuture';
import Footer from './Components/Footer';

function App() {
  return (
    <div>
      <Index/>
      <EngineeredExcellence/>
      <MernSolution/>
      <TransformingBusiness/>
      <Result/>
      <EngineerMethodology/>
      <Technical/>
      <CommonQuestion/>
      <Digital/>
      <Commitment/>
      <DigitalFuture/>
      <Footer/>
    </div>
  );
}

export default App;