import React from 'react';

const Commitment: React.FC = () => {

    const handleWhatsAppClick = () => {
    const whatsappNumber = "919146677505";
    const defaultMessage = encodeURIComponent("Hello! I'm interested in your MERN stack development services. Let's discuss our project in detail.");
    
    window.open(`https://wa.me/${whatsappNumber}?text=${defaultMessage}`, '_blank');
  };

  const handleCallClick = () => {
    window.location.href = 'tel:+919146677505';
  };

  return (
    <div className="min-h-screen bg-white pt-10">
      {/* Header Section */}
      <section className="pt-4 pb-5 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center px-5 py-3 rounded-full bg-white shadow-lg border border-cyan-100 mb-3">
            <i className="fas fa-handshake text-green-500 mr-2"></i>
            <span className="text-cyan-700 ">OUR COMMITMENTS TO YOU</span>
          </div>
          <h1 className="text-4xl md:text-4xl font-bold text-gray-800 mb-2 leading-tight">
            Built on <span className="cyan-gradient-text">Trust</span> & 
            <span className="green-gradient-text"> Excellence</span>
          </h1>
          <p className="text-sm text-gray-600 max-w-3xl mx-auto leading-relaxed">
            We believe in establishing clear expectations and delivering on our promises.
          </p>
        </div>
      </section>

      {/* Main Commitments */}
      <section className="py-5 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Quality Guarantee */}
            <div className="bg-white rounded-2xl shadow-xl commitment-card border-t-4 border-cyan-500 p-8 card-hover hover:shadow-2xl transition-all duration-300">
              <div className="w-16 h-16 rounded-2xl bg-cyan-100 flex items-center justify-center mb-6 shadow-sm">
                <i className="fas fa-award text-cyan-600 text-2xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Quality Guarantee</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                We deliver clean, documented, and tested code that meets industry standards. If our work doesn't meet agreed-upon requirements, we'll fix it at no additional cost.
              </p>
              <div className="flex items-center text-cyan-600 bg-cyan-50 px-4 py-2 rounded-lg">
                <i className="fas fa-shield-check mr-2"></i>
                <span className="font-semibold">Industry Standards Compliant</span>
              </div>
            </div>

            {/* Transparency Promise */}
            <div className="bg-white rounded-2xl shadow-xl commitment-card border-t-4 border-green-500 p-8 card-hover hover:shadow-2xl transition-all duration-300">
              <div className="w-16 h-16 rounded-2xl bg-green-100 flex items-center justify-center mb-6 shadow-sm">
                <i className="fas fa-eye text-green-600 text-2xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Transparency Promise</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                You'll always know the status of your project with regular updates, access to project management tools, and clear communication throughout the development process.
              </p>
              <div className="flex items-center text-green-600 bg-green-50 px-4 py-2 rounded-lg">
                <i className="fas fa-comments mr-2"></i>
                <span className="font-semibold">Clear Communication</span>
              </div>
            </div>

            {/* Long-term Support */}
            <div className="bg-white rounded-2xl shadow-xl commitment-card border-t-4 border-cyan-500 p-8 card-hover hover:shadow-2xl transition-all duration-300">
              <div className="w-16 h-16 rounded-2xl bg-cyan-100 flex items-center justify-center mb-6 shadow-sm">
                <i className="fas fa-headset text-cyan-600 text-2xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Long-term Support</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                Our relationship doesn't end at launch. We provide ongoing maintenance and support to ensure your digital assets continue to perform optimally and adapt to changing needs.
              </p>
              <div className="flex items-center text-cyan-600 bg-cyan-50 px-4 py-2 rounded-lg">
                <i className="fas fa-infinity mr-2"></i>
                <span className="font-semibold">Ongoing Partnership</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Satisfaction Guarantee Section */}
      <section className="py-5 px-4 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 card-hover border-t-4 border-green-500">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Left Content */}
              <div>
                <div className="bg-gradient-to-r from-cyan-50 to-green-50 rounded-2xl p-6 md:p-8 border border-cyan-100 mb-8">
                  <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Satisfaction Guarantee</h2>
                  <p className="text-gray-600 leading-relaxed">
                    We're committed to your complete satisfaction with every project we deliver. Our process includes regular review checkpoints to ensure alignment with your requirements. If any aspect of our work doesn't meet the agreed-upon specifications, we'll address it promptly at no additional cost.
                  </p>
                </div>

                {/* Benefits Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-center p-4 bg-cyan-50 rounded-xl border border-cyan-100">
                    <i className="fas fa-calendar-check text-cyan-600 text-xl mr-4"></i>
                    <span className="font-semibold text-gray-800">30-day post-launch support</span>
                  </div>
                  <div className="flex items-center p-4 bg-green-50 rounded-xl border border-green-100">
                    <i className="fas fa-file-alt text-green-600 text-xl mr-4"></i>
                    <span className="font-semibold text-gray-800">Detailed documentation</span>
                  </div>
                  <div className="flex items-center p-4 bg-cyan-50 rounded-xl border border-cyan-100">
                    <i className="fas fa-code text-cyan-600 text-xl mr-4"></i>
                    <span className="font-semibold text-gray-800">Code ownership transfer</span>
                  </div>
                  <div className="flex items-center p-4 bg-green-50 rounded-xl border border-green-100">
                    <i className="fas fa-graduation-cap text-green-600 text-xl mr-4"></i>
                    <span className="font-semibold text-gray-800">Training and knowledge transfer</span>
                  </div>
                </div>
              </div>

              {/* Right Visual */}
              <div className="flex flex-col justify-center items-center text-center">
                <div className="w-32 h-32 bg-gradient-to-r from-cyan-600 to-green-500 rounded-full flex items-center justify-center mb-8 shadow-xl">
                  <div className="w-28 h-28 bg-white/20 rounded-full flex items-center justify-center">
                    <i className="fas fa-star text-white text-4xl"></i>
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">100% Satisfaction Guaranteed</h3>
                <p className="text-gray-600 mb-6 max-w-md">
                  Your complete satisfaction is our top priority. We stand behind our work with comprehensive guarantees.
                </p>
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-cyan-50 rounded-xl p-4 text-center border border-cyan-100">
                    <div className="text-2xl font-bold text-cyan-600">100%</div>
                    <div className="text-sm text-gray-600">Quality Standards</div>
                  </div>
                  <div className="bg-green-50 rounded-xl p-4 text-center border border-green-100">
                    <div className="text-2xl font-bold text-green-600">0%</div>
                    <div className="text-sm text-gray-600">Hidden Costs</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-4 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-r from-cyan-600 to-green-500 rounded-3xl p-8 md:p-12 text-white shadow-2xl relative overflow-hidden">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white rounded-full -mr-32 -mt-32"></div>
              <div className="absolute bottom-0 left-0 w-64 h-64 bg-white rounded-full -ml-32 -mb-32"></div>
            </div>
            
            <div className="relative z-10">
              <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg border border-white/30">
                <i className="fas fa-rocket text-2xl"></i>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to experience our professional service?</h2>
              <p className="text-cyan-100 text-lg md:text-xl mb-8 max-w-2xl mx-auto">
                Partner with a team that stands behind its work with comprehensive guarantees and unwavering commitment to your success.
              </p>
              <button onClick={handleWhatsAppClick} className="bg-white text-cyan-700 font-semibold py-4 px-12 rounded-xl hover:bg-gray-50 transition-all duration-300 flex items-center justify-center mx-auto shadow-lg hover:shadow-xl text-lg hover:scale-[1.02]">
                <i className="fas fa-play-circle mr-3"></i>
                Start Your Project
              </button>
              <div className="mt-6 flex flex-wrap justify-center gap-6 text-cyan-100">
                <div className="flex items-center">
                  <i className="fas fa-check-circle mr-2"></i>
                  <span>No-risk consultation</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-check-circle mr-2"></i>
                  <span>Transparent pricing</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-check-circle mr-2"></i>
                  <span>Guaranteed satisfaction</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-4 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-white rounded-2xl p-6 text-center shadow-md border border-cyan-100">
              <i className="fas fa-clock text-cyan-600 text-3xl mb-3"></i>
              <p className="font-bold text-gray-800">On-time Delivery</p>
            </div>
            <div className="bg-white rounded-2xl p-6 text-center shadow-md border border-green-100">
              <i className="fas fa-lock text-green-600 text-3xl mb-3"></i>
              <p className="font-bold text-gray-800">Secure Development</p>
            </div>
            <div className="bg-white rounded-2xl p-6 text-center shadow-md border border-cyan-100">
              <i className="fas fa-chart-line text-cyan-600 text-3xl mb-3"></i>
              <p className="font-bold text-gray-800">Performance Focus</p>
            </div>
            <div className="bg-white rounded-2xl p-6 text-center shadow-md border border-green-100">
              <i className="fas fa-users text-green-600 text-3xl mb-3"></i>
              <p className="font-bold text-gray-800">Dedicated Team</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Commitment;