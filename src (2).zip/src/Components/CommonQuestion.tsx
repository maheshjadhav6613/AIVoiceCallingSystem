import React from 'react';

const CommonQuestion: React.FC = () => {
    const handleWhatsAppClick = () => {
    const whatsappNumber = "919146677505";
    const defaultMessage = encodeURIComponent("Hello! I'm interested in your MERN stack development services. Book a Free Consultation");
    
    window.open(`https://wa.me/${whatsappNumber}?text=${defaultMessage}`, '_blank');
  };

  const handleCallClick = () => {
    window.location.href = 'tel:+919146677505';
  };
  return (
    <div className="min-h-screen bg-white">
      <style>{`
        .cyan-gradient-text {
          background: \`linear-gradient(90deg, #06b6d4, #0891b2)\`;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .green-gradient-text {
          background: \`linear-gradient(90deg, #22c55e, #16a34a)\`;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .card-hover {
          transition: all 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 15px 30px rgba(6, 182, 212, 0.1);
        }
      `}</style>
      
      {/* Header Section */}
      <section className="pt-12 pb-5 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center px-5 py-3 rounded-full bg-white shadow-lg border border-cyan-100 mb-3">
            <i className="fas fa-comments text-green-500 mr-2"></i>
            <span className="text-cyan-700  text-sm">TRANSPARENCY BUILDS TRUST</span>
          </div>
          <h1 className="text-4xl md:text-4xl font-bold text-gray-800 mb-2 leading-tight">
            Common <span className="cyan-gradient-text">Questions</span>
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto text-sm">
            We're open about our processes, pricing, and approach. Transparency is at the core of everything we do.
          </p>
        </div>
      </section>

      {/* FAQ Grid Section - Card Layout */}
      <section className="py-5 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            {/* FAQ Card 1 */}
            <div className="bg-white rounded-2xl shadow-lg border border-cyan-100 card-hover overflow-hidden">
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-indian-rupee-sign text-cyan-600 text-lg"></i>
                  </div>
                  <h3 className="text-lg font-bold text-gray-800">How does your pricing structure work?</h3>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">
                  We offer transparent, value-based pricing with flexible models including fixed price projects, retainer agreements, and time & materials.
                </p>
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center text-cyan-600 text-xs font-medium">
                    <i className="fas fa-tag mr-2"></i>
                    <span>Projects from ₹20,000 to ₹45,00,000</span>
                  </div>
                </div>
              </div>
            </div>

            {/* FAQ Card 2 */}
            <div className="bg-white rounded-2xl shadow-lg border border-green-100 card-hover overflow-hidden">
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-globe text-green-600 text-lg"></i>
                  </div>
                  <h3 className="text-lg font-bold text-gray-800">How do you handle project management across time zones?</h3>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">
                  Our team has extensive experience working with global clients. We establish overlap hours and maintain detailed documentation.
                </p>
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center text-green-600 text-xs font-medium">
                    <i className="fas fa-map-marker-alt mr-2"></i>
                    <span>India, Dubai, Singapore & UK</span>
                  </div>
                </div>
              </div>
            </div>

            {/* FAQ Card 3 */}
            <div className="bg-white rounded-2xl shadow-lg border border-cyan-100 card-hover overflow-hidden">
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-shield-alt text-cyan-600 text-lg"></i>
                  </div>
                  <h3 className="text-lg font-bold text-gray-800">How do you ensure code quality and security?</h3>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">
                  Quality and security are built into our process through code reviews, automated testing, and security audits.
                </p>
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center text-cyan-600 text-xs font-medium">
                    <i className="fas fa-check-circle mr-2"></i>
                    <span>Industry best practices & peer reviews</span>
                  </div>
                </div>
              </div>
            </div>

            {/* FAQ Card 4 */}
            <div className="bg-white rounded-2xl shadow-lg border border-green-100 card-hover overflow-hidden">
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-calendar-alt text-green-600 text-lg"></i>
                  </div>
                  <h3 className="text-lg font-bold text-gray-800">What is your typical project timeline?</h3>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">
                  Project timelines vary based on complexity. We follow agile methodology with regular sprints and clear milestones.
                </p>
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center text-green-600 text-xs font-medium">
                    <i className="fas fa-clock mr-2"></i>
                    <span>2 weeks to 3+ months</span>
                  </div>
                </div>
              </div>
            </div>

            {/* FAQ Card 5 */}
            <div className="bg-white rounded-2xl shadow-lg border border-cyan-100 card-hover overflow-hidden">
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-headset text-cyan-600 text-lg"></i>
                  </div>
                  <h3 className="text-lg font-bold text-gray-800">What ongoing support do you provide?</h3>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">
                  We offer comprehensive post-launch support including 24/7 monitoring, maintenance, and performance optimization.
                </p>
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center text-cyan-600 text-xs font-medium">
                    <i className="fas fa-life-ring mr-2"></i>
                    <span>Customizable support packages</span>
                  </div>
                </div>
              </div>
            </div>

            {/* FAQ Card 6 */}
            <div className="bg-white rounded-2xl shadow-lg border border-green-100 card-hover overflow-hidden">
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-star text-green-600 text-lg"></i>
                  </div>
                  <h3 className="text-lg font-bold text-gray-800">What makes ARRCTECHE different?</h3>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">
                  Deep MERN stack specialization, international experience, and transparent engineering approach set us apart.
                </p>
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center text-green-600 text-xs font-medium">
                    <i className="fas fa-rocket mr-2"></i>
                    <span>Strategic technology partners</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

    

      {/* CTA Section */}
      <section className="py-8 px-4">
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-gradient-to-r from-cyan-600 to-green-500 rounded-2xl p-8 shadow-xl">
            <div className="text-white">
              <h3 className="text-2xl font-bold mb-4">Still have questions?</h3>
              <p className="mb-6 opacity-90">Schedule a free consultation call with our technical lead</p>
              <button onClick={handleWhatsAppClick} className="bg-white text-cyan-700 font-semibold py-3 px-8 rounded-xl hover:bg-gray-50 transition-all duration-300 flex items-center justify-center mx-auto shadow-lg hover:shadow-xl hover:scale-[1.02]">
                <i className="fas fa-calendar-check mr-3"></i>
                Book a Free Consultation
              </button>
              <p className="text-cyan-100 text-sm mt-4">
                <i className="fas fa-clock mr-2"></i>
                30-minute session • No obligation
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CommonQuestion;