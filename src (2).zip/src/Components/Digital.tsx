import React from 'react';

const Digital: React.FC = () => {

    const handleWhatsAppClick = () => {
    const whatsappNumber = "919146677505";
    const defaultMessage = encodeURIComponent("Hello! I'm interested in your MERN stack development services.   Book Your Strategy Session");
    
    window.open(`https://wa.me/${whatsappNumber}?text=${defaultMessage}`, '_blank');
  };



  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-6xl w-full">
        {/* Main CTA Card */}
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden" style={{ minHeight: '70vh' }}>
          <div className="grid grid-cols-1 lg:grid-cols-2 h-full">
            {/* Left Content */}
            <div className="bg-gradient-to-br from-cyan-600 via-cyan-500 to-green-500 p-8 lg:p-12 flex flex-col justify-center items-center text-white relative overflow-hidden">
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-0 right-0 w-80 h-80 bg-white rounded-full -mr-40 -mt-40"></div>
                <div className="absolute bottom-0 left-0 w-80 h-80 bg-white rounded-full -ml-40 -mb-40"></div>
              </div>
              
              {/* Content */}
              <div className="relative z-10 text-center w-full">
                {/* Main Icon */}
                <div className="w-28 h-28 bg-white/20 backdrop-blur-sm rounded-3xl flex items-center justify-center mx-auto mb-10 shadow-2xl border border-white/30">
                  <i className="fas fa-handshake text-4xl"></i>
                </div>

                <h2 className="text-3xl font-bold mb-10">Partnership Results</h2>

                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-6 mb-10">
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                    <div className="text-4xl font-bold mb-2">23</div>
                    <div className="text-cyan-100 text-sm font-medium">Expert Engineers</div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                    <div className="text-4xl font-bold mb-2">7+</div>
                    <div className="text-green-100 text-sm font-medium">Years Experience</div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                    <div className="text-4xl font-bold mb-2">500+</div>
                    <div className="text-cyan-100 text-sm font-medium">Projects Delivered</div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                    <div className="text-4xl font-bold mb-2">98%</div>
                    <div className="text-green-100 text-sm font-medium">Success Rate</div>
                  </div>
                </div>

                {/* Success Metrics */}
                <div className="space-y-5 mb-10">
                  <div className="flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                    <i className="fas fa-chart-line text-amber-300 mr-4 text-xl"></i>
                    <div className="text-left">
                      <div className="font-bold text-lg">400% Performance Gains</div>
                      <div className="text-cyan-100 text-sm">Average improvement for our clients</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                    <i className="fas fa-users text-green-300 mr-4 text-xl"></i>
                    <div className="text-left">
                      <div className="font-bold text-lg">78% User Engagement Increase</div>
                      <div className="text-cyan-100 text-sm">Enhanced user experience metrics</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                    <i className="fas fa-shield-alt text-cyan-300 mr-4 text-xl"></i>
                    <div className="text-left">
                      <div className="font-bold text-lg">Enterprise-Grade Security</div>
                      <div className="text-cyan-100 text-sm">Industry-leading security protocols</div>
                    </div>
                  </div>
                </div>

                {/* Trust Indicator */}
                <div className="flex items-center justify-center space-x-4 text-sm">
                  <div className="flex items-center">
                    <i className="fas fa-check-circle text-green-300 mr-2"></i>
                    <span>Guaranteed Results</span>
                  </div>
                  <div className="h-4 w-px bg-white/30"></div>
                  <div className="flex items-center">
                    <i className="fas fa-lock text-cyan-300 mr-2"></i>
                    <span>Secure Consultation</span>
                  </div>
                </div>
              </div>
            </div>
            

            {/* Right Visual Section */}
            <div className="p-8 lg:p-12 flex flex-col justify-center">
              {/* Header */}
              <div className="mb-8">
                <div className="inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-cyan-50 to-green-50 text-cyan-700 text-sm font-medium mb-6 border border-cyan-200">
                  <i className="fas fa-rocket text-green-500 mr-2"></i>
                  <span className="">LIMITED AVAILABILITY • Q1 2024</span>
                </div>
                <h1 className="text-4xl md:text-4xl font-bold text-gray-800 mb-6 leading-tight">
                  Transform Your Vision Into 
                  <span className="cyan-gradient-text"> Digital Reality</span>
                </h1>
                <p className="text-lg text-gray-600 leading-relaxed">
                  Partner with expert engineers to build high-performance digital solutions that drive measurable business growth.
                </p>
              </div>

              {/* Benefits List */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
                  <i className="fas fa-gift text-cyan-600 mr-3"></i>
                  What You'll Get From This Consultation:
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start bg-gradient-to-r from-cyan-50/50 to-white p-4 rounded-xl border border-cyan-100">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-cyan-100 flex items-center justify-center mr-4 mt-1">
                      <i className="fas fa-clipboard-check text-cyan-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-1">Detailed Technical Assessment</h4>
                      <p className="text-gray-600 text-sm">Comprehensive analysis of your requirements and existing systems</p>
                    </div>
                  </div>
                  <div className="flex items-start bg-gradient-to-r from-green-50/50 to-white p-4 rounded-xl border border-green-100">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-4 mt-1">
                      <i className="fas fa-chart-line text-green-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-1">Transparent Project Roadmap</h4>
                      <p className="text-gray-600 text-sm">Clear scope, timeline, and investment requirements</p>
                    </div>
                  </div>
                  <div className="flex items-start bg-gradient-to-r from-cyan-50/50 to-white p-4 rounded-xl border border-cyan-100">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-cyan-100 flex items-center justify-center mr-4 mt-1">
                      <i className="fas fa-lightbulb text-cyan-600 text-sm"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-1">Strategic Growth Plan</h4>
                      <p className="text-gray-600 text-sm">Customized recommendations for maximum business impact</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Consultation Details */}
              <div className="bg-gradient-to-r from-cyan-50 to-green-50 rounded-xl p-4 mb-8 border border-cyan-200">
                <div className="flex items-start">
                  <i className="fas fa-video text-green-600 text-xl mr-4 mt-1"></i>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-1">45-Minute Strategy Session</h4>
                    <p className="text-gray-600 text-sm">One-on-one with a senior technical architect and business consultant</p>
                  </div>
                </div>
              </div>

              {/* CTA Button */}
              <div>
                <button onClick={handleWhatsAppClick} className="w-full bg-gradient-to-r from-cyan-600 to-green-500 text-white font-semibold py-4 px-8 rounded-xl hover:from-cyan-700 hover:to-green-600 transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl text-lg hover:scale-[1.02]">
                  <i className="fas fa-calendar-check mr-3 text-lg"></i>
                  Book Your Strategy Session
                </button>
                <p className="text-center text-gray-500 text-sm mt-3">
                  No cost • No obligation • 100% confidential
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Note */}
        
      </div>
    </div>
  );
};

export default Digital;