import React, { useState } from 'react';

const DigitalFuture: React.FC = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    company: '',
    budget: '',
    requirements: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const formatMessage = () => {
    const message = `*New Project Inquiry*\n\n` +
      `*Name:* ${formData.fullName}\n` +
      `*Email:* ${formData.email}\n` +
      `*Phone:* ${formData.phone}\n` +
      `*Company:* ${formData.company || 'Not provided'}\n` +
      `*Budget Range:* ${formData.budget}\n\n` +
      `*Project Requirements:*\n${formData.requirements}\n\n` +
      `---\n*Sent via Website Form*`;
    
    return encodeURIComponent(message);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // WhatsApp number
    const whatsappNumber = "919146677505"; // Remove any spaces or plus sign
    const message = formatMessage();
    
    // Open WhatsApp with pre-filled message
    window.open(`https://wa.me/${whatsappNumber}?text=${message}`, '_blank');
    
    // Log for debugging
    console.log('Form submitted:', formData);
    console.log('WhatsApp URL:', `https://wa.me/${whatsappNumber}?text=${message}`);
  };

  const handleWhatsAppClick = () => {
    const whatsappNumber = "919146677505";
    const defaultMessage = encodeURIComponent("Hello! I'm interested in your MERN stack development services. Can we discuss my project?");
    
    window.open(`https://wa.me/${whatsappNumber}?text=${defaultMessage}`, '_blank');
  };

  const handleCallClick = () => {
    window.location.href = 'tel:+919146677505';
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-50/20 to-green-50/20">
      {/* Header Section */}
      <section className="pt-10 pb-5 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center px-5 py-3 rounded-full bg-white shadow-lg border border-cyan-100 mb-3">
            <i className="fas fa-rocket text-green-500 mr-2"></i>
            <span className="text-cyan-700">LET'S BUILD YOUR DIGITAL FUTURE</span>
          </div>
          <h1 className="text-4xl md:text-4xl font-bold text-gray-800 mb-2 leading-tight">
            Transform Your <span className="cyan-gradient-text">Business</span>
          </h1>
          <p className="text-sm text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Ready to transform your business with modern web technology? Our team of MERN stack experts is here to bring your vision to life.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="pt-5 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Left Column - Process & Contact */}
            <div className="space-y-8">
              {/* Process Steps */}
              <div className="bg-white rounded-3xl shadow-xl p-8 card-hover border-t-4 border-cyan-500">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-cyan-600 to-green-500 flex items-center justify-center mr-4">
                    <i className="fas fa-list-ol text-white text-lg"></i>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-800">Our Simple Process</h2>
                </div>
                
                <div className="space-y-6">
                  {/* Step 1 */}
                  <div className="step-card border-l-4 border-cyan-500 p-6 bg-gradient-to-r from-cyan-50 to-white rounded-xl">
                    <div className="flex items-start">
                      <div className="w-12 h-12 rounded-xl bg-cyan-100 flex items-center justify-center mr-4 flex-shrink-0 shadow-sm">
                        <span className="text-cyan-700 font-bold text-lg">1</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-800 mb-2">Book a Consultation</h3>
                        <p className="text-gray-600">
                          Schedule a 30-minute call with our team to discuss your requirements and explore potential solutions.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="step-card border-l-4 border-green-500 p-6 bg-gradient-to-r from-green-50 to-white rounded-xl">
                    <div className="flex items-start">
                      <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center mr-4 flex-shrink-0 shadow-sm">
                        <span className="text-green-600 font-bold text-lg">2</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-800 mb-2">Receive a Proposal</h3>
                        <p className="text-gray-600">
                          We'll provide a detailed proposal with project scope, timeline, and transparent pricing.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className="step-card border-l-4 border-cyan-500 p-6 bg-gradient-to-r from-cyan-50 to-white rounded-xl">
                    <div className="flex items-start">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-100 to-green-100 flex items-center justify-center mr-4 flex-shrink-0 shadow-sm">
                        <span className="text-cyan-700 font-bold text-lg">3</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-800 mb-2">Begin Your Journey</h3>
                        <p className="text-gray-600">
                          Start your project with confidence, supported by our experienced development team.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              {/* Contact Information */}
              <div className="bg-gradient-to-r from-cyan-600 to-green-500 rounded-3xl p-8 text-white text-center shadow-xl relative overflow-hidden">
                {/* Background Pattern */}
                <div className="absolute inset-0 opacity-10">
                  <div className="absolute top-0 right-0 w-40 h-40 bg-white rounded-full -mr-20 -mt-20"></div>
                  <div className="absolute bottom-0 left-0 w-40 h-40 bg-white rounded-full -ml-20 -mb-20"></div>
                </div>
                
                <div className="relative z-10">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg border border-white/30">
                    <i className="fas fa-phone-alt text-xl"></i>
                  </div>
                  <div className="space-y-3">
                    <button 
                      onClick={handleWhatsAppClick}
                      className="w-full bg-white text-cyan-700 font-semibold py-3 px-6 rounded-xl hover:bg-gray-50 transition-all duration-300 flex items-center justify-center shadow-lg hover:scale-[1.02]"
                    >
                      <i className="fab fa-whatsapp mr-3 text-green-500 text-lg"></i>
                      WhatsApp Us
                    </button>
                    <button 
                      onClick={handleCallClick}
                      className="w-full bg-white/20 backdrop-blur-sm text-white font-semibold py-3 px-6 rounded-xl hover:bg-white/30 transition-all duration-300 flex items-center justify-center border border-white/30"
                    >
                      <i className="fas fa-phone mr-3 text-white text-lg"></i>
                      Call Now
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Contact Form */}
            <div className="bg-white rounded-3xl shadow-xl p-8 card-hover border-t-4 border-green-500">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-cyan-600 to-green-500 flex items-center justify-center mr-4">
                  <i className="fas fa-envelope text-white text-lg"></i>
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-800">Let's Discuss Your Project</h2>
                  <p className="text-gray-600">Fill out the form below and submit to start a WhatsApp conversation.</p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                    <i className="fas fa-user text-cyan-500 mr-2 text-sm"></i>
                    Full Name *
                  </label>
                  <input 
                    type="text" 
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all duration-300" 
                    placeholder="Enter your full name"
                    required
                  />
                </div>

                {/* Email & Phone */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                      <i className="fas fa-envelope text-cyan-500 mr-2 text-sm"></i>
                      Email ID *
                    </label>
                    <input 
                      type="email" 
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all duration-300" 
                      placeholder="your@email.com"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                      <i className="fas fa-phone text-green-500 mr-2 text-sm"></i>
                      Phone Number *
                    </label>
                    <input 
                      type="tel" 
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-300" 
                      placeholder="+91 00000 00000"
                      required
                    />
                  </div>
                </div>

                {/* Company */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                    <i className="fas fa-building text-cyan-500 mr-2 text-sm"></i>
                    Company Name
                  </label>
                  <input 
                    type="text" 
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all duration-300" 
                    placeholder="Your company name"
                  />
                </div>

                {/* Budget */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                    <i className="fas fa-indian-rupee-sign text-green-500 mr-2 text-sm"></i>
                    Select Budget Range *
                  </label>
                  <select 
                    name="budget"
                    value={formData.budget}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-300"
                    required
                  >
                    <option value="">Choose your budget range</option>
                    <option value="₹20,000 - ₹50,000">₹20,000 - ₹50,000</option>
                    <option value="₹50,000 - ₹2,00,000">₹50,000 - ₹2,00,000</option>
                    <option value="₹2,00,000 - ₹5,00,000">₹2,00,000 - ₹5,00,000</option>
                    <option value="₹5,00,000+">₹5,00,000+</option>
                    <option value="Custom Budget">Custom Budget</option>
                  </select>
                </div>

                {/* Project Requirements */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
                    <i className="fas fa-edit text-cyan-500 mr-2 text-sm"></i>
                    Tell us about your project requirements *
                  </label>
                  <textarea 
                    name="requirements"
                    value={formData.requirements}
                    onChange={handleChange}
                    rows={4} 
                    className="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all duration-300" 
                    placeholder="Describe your project goals, features, timeline, and any specific requirements..."
                    required
                  ></textarea>
                </div>

                {/* Submit Button */}
                <button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-cyan-600 to-green-500 text-white font-semibold py-4 px-8 rounded-xl hover:from-cyan-700 hover:to-green-600 transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl hover:scale-[1.02]"
                >
                  <i className="fab fa-whatsapp mr-3 text-xl"></i>
                  SEND TO WHATSAPP
                </button>

              
                {/* Privacy Policy */}
                <div className="flex items-start text-xs text-gray-500">
                  <i className="fas fa-shield-alt text-cyan-500 mt-0.5 mr-2"></i>
                  <p>
                    By submitting this form, you agree to our Privacy Policy and consent to being contacted regarding your inquiry.
                    Your data will be sent via WhatsApp for faster response.
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* WhatsApp Floating Button */}
      <div className="fixed  bottom-6 right-6 z-50">
  <button 
    onClick={handleWhatsAppClick}
    className="
      bg-gradient-to-r from-green-500 to-green-600 
      text-white 
      h-10 w-10 lg:h-12 lg:w-12
      flex items-center justify-center
      rounded-full shadow-2xl 
      hover:shadow-3xl hover:scale-110 
      transition-all duration-300 
      animate-bounce-slow
    "
  >
    <i className="fab fa-whatsapp text-sm lg:text-lg"></i>
  </button>
</div>

<div className="fixed bottom-18 md:bottom-20 right-6 z-50">
  <button 
    onClick={handleCallClick}
    className="
      bg-gradient-to-r from-cyan-500 to-cyan-600 
      text-white 
      h-10 w-10 lg:h-12 lg:w-12
      flex items-center justify-center
      rounded-full shadow-2xl 
      hover:shadow-3xl hover:scale-110 
      transition-all duration-300 
      animate-bounce-slow
    "
  >
    <i className="fas fa-phone text-sm lg:text-lg"></i>
  </button>
</div>


      {/* Trust Indicators */}
      <section className="py-5 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-2xl p-6 text-center shadow-md border border-cyan-100">
              <div className="w-12 h-12 rounded-xl bg-cyan-100 flex items-center justify-center mx-auto mb-3">
                <i className="fab fa-whatsapp text-green-600"></i>
              </div>
              <h4 className="font-bold text-gray-800 mb-1">WhatsApp Response</h4>
              <p className="text-gray-600 text-sm">Instant response via WhatsApp chat</p>
            </div>
            <div className="bg-white rounded-2xl p-6 text-center shadow-md border border-green-100">
              <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center mx-auto mb-3">
                <i className="fas fa-lock text-green-600"></i>
              </div>
              <h4 className="font-bold text-gray-800 mb-1">Secure & Confidential</h4>
              <p className="text-gray-600 text-sm">Your information is protected</p>
            </div>
            <div className="bg-white rounded-2xl p-6 text-center shadow-md border border-cyan-100">
              <div className="w-12 h-12 rounded-xl bg-cyan-100 flex items-center justify-center mx-auto mb-3">
                <i className="fas fa-headset text-cyan-600"></i>
              </div>
              <h4 className="font-bold text-gray-800 mb-1">Free Consultation</h4>
              <p className="text-gray-600 text-sm">No cost WhatsApp consultation</p>
            </div>
          </div>
        </div>
      </section>

      {/* Add CSS for animations */}
      <style>{`
        .animate-bounce-slow {
          animation: bounce 2s infinite;
        }
        @keyframes bounce {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-10px);
          }
        }
        .cyan-gradient-text {
          background: linear-gradient(135deg, #06b6d4, #10b981);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        .card-hover {
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }
        .step-card {
          transition: transform 0.3s ease;
        }
        .step-card:hover {
          transform: translateX(5px);
        }
      `}</style>
    </div>
  );
};

export default DigitalFuture;