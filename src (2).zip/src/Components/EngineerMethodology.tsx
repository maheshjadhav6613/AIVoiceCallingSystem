import React from 'react';

const EngineerMethodology: React.FC = () => {

  const handleWhatsAppClick = () => {
    const whatsappNumber = "919146677505";
    const defaultMessage = encodeURIComponent("Hello! I'm interested in your MERN stack development services.  Schedule Virtual Meeting");
    
    window.open(`https://wa.me/${whatsappNumber}?text=${defaultMessage}`, '_blank');
  };

  const handleCallClick = () => {
    window.location.href = 'tel:+919146677505';
  };

  return (
    <div className="min-h-screen bg-white">
      <style>{`
        .card-hover {
          transition: all 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
        }
        .cyan-gradient-text {
          background: linear-gradient(90deg, #06b6d4, #0891b2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .green-gradient-text {
          background: linear-gradient(90deg, #22c55e, #16a34a);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .step-number {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          font-size: 18px;
        }
      `}</style>

      {/* Header Section */}
      <section className="pt-16 pb-4 px-4">  
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center px-5 py-3 rounded-full bg-white shadow-lg border border-cyan-100 mb-2">
            <i className="fas fa-cogs text-green-500 mr-2"></i>
            <span className="text-cyan-700 ">STRUCTURED ENGINEERING APPROACH</span>
          </div>
          <h1 className="text-4xl md:text-4xl font-bold text-gray-800 mb-2 leading-tight">
            Our Engineering <span className="cyan-gradient-text">Methodology</span>
          </h1>
          <p className="text-sm text-gray-600 max-w-3xl mx-auto leading-relaxed">
            A structured, transparent approach that ensures quality, efficiency, and predictable outcomes.
          </p>
        </div>
      </section>

      {/* Methodology Process */}
      <section className="py-5 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Discover */}
            <div className="bg-white rounded-2xl shadow-lg methodology-step border-l-4 border-cyan-500 p-6 card-hover">
              <div className="flex items-center mb-4">
                <div className="step-number bg-cyan-100 text-cyan-700 mr-4">1</div>
                <h3 className="text-xl font-bold text-gray-800">Discover</h3>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fas fa-check text-cyan-600 mt-1 mr-3"></i>
                  <span className="text-gray-600">Avoidance delays, interference, and barriers per segment</span>
                </li>
              </ul>
            </div>

            {/* Plan */}
            <div className="bg-white rounded-2xl shadow-lg methodology-step border-l-4 border-green-500 p-6 card-hover">
              <div className="flex items-center mb-4">
                <div className="step-number bg-green-100 text-green-700 mr-4">2</div>
                <h3 className="text-xl font-bold text-gray-800">Plan</h3>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fas fa-check text-green-600 mt-1 mr-3"></i>
                  <span className="text-gray-600">Accelerate delay, discharge selection, and proper readings results</span>
                </li>
              </ul>
            </div>

            {/* Build */}
            <div className="bg-white rounded-2xl shadow-lg methodology-step border-l-4 border-cyan-500 p-6 card-hover">
              <div className="flex items-center mb-4">
                <div className="step-number bg-cyan-100 text-cyan-700 mr-4">3</div>
                <h3 className="text-xl font-bold text-gray-800">Build</h3>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fas fa-check text-cyan-600 mt-1 mr-3"></i>
                  <span className="text-gray-600">Agile development targets, cash receipts, and contextual examples</span>
                </li>
              </ul>
            </div>

            {/* Test */}
            <div className="bg-white rounded-2xl shadow-lg methodology-step border-l-4 border-green-500 p-6 card-hover">
              <div className="flex items-center mb-4">
                <div className="step-number bg-green-100 text-green-700 mr-4">4</div>
                <h3 className="text-xl font-bold text-gray-800">Test</h3>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fas fa-check text-green-600 mt-1 mr-3"></i>
                  <span className="text-gray-600">Accelerate timing, six processes, and security scaling</span>
                </li>
              </ul>
            </div>

            {/* Deploy */}
            <div className="bg-white rounded-2xl shadow-lg methodology-step border-l-4 border-cyan-500 p-6 card-hover">
              <div className="flex items-center mb-4">
                <div className="step-number bg-cyan-100 text-cyan-700 mr-4">5</div>
                <h3 className="text-xl font-bold text-gray-800">Deploy</h3>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fas fa-check text-cyan-600 mt-1 mr-3"></i>
                  <span className="text-gray-600">Continuous deployment, infrastructure monitoring and monitoring steps</span>
                </li>
              </ul>
            </div>

            {/* Maintain */}
            <div className="bg-white rounded-2xl shadow-lg methodology-step border-l-4 border-green-500 p-6 card-hover">
              <div className="flex items-center mb-4">
                <div className="step-number bg-green-100 text-green-700 mr-4">6</div>
                <h3 className="text-xl font-bold text-gray-800">Maintain</h3>
              </div>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fas fa-check text-green-600 mt-1 mr-3"></i>
                  <span className="text-gray-600">Practice maintenance, performance monitoring, and continuous transportation</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
{/* Founder & Philosophy Section */}
<section className="py-5 md:py-5 bg-white">
  <div className="max-w-6xl mx-auto px-4">
    <div className="grid grid-cols-1 lg:grid-cols-2 justify-center gap-8 md:gap-12">
      {/* Founder Card */}
      <div className="bg-white rounded-3xl  shadow-xl p-6 md:p-8 card-hover border-l-4 border-cyan-500 relative overflow-hidden">
        {/* Decorative corner */}
        <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-cyan-500/10 to-green-500/10 rounded-bl-3xl"></div>
        
        <div className="flex items-center flex-col justify-center mb-6 relative z-10">
          <div className="w-20 h-20 md:w-60 md:h-60 rounded-2xl bg-gradient-to-br from-cyan-600 to-green-500 p-1 flex items-center justify-center mr-4 md:mr-6 shadow-lg">
            <div className="w-full h-full rounded-2xl bg-white overflow-hidden">
              <img 
                src="/image.png" 
                alt="M. Mahendraa" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          <div className='text-center'>
            <h3 className="text-xl md:text-2xl mt-3 font-bold text-gray-500 mb-1">Mr. Mahendraa</h3>
            <p className="text-cyan-600 font-medium text-sm md:text-center">Founder & Lead Engineer</p>
            <div className="flex justify-center items-center mt-2 text-green-600">
              <i className="fas fa-certificate text-xs mr-1"></i>
              <span className="text-xs font-medium">Certified Expert</span>
            </div>
          </div>
        </div>
        
        <div className="mb-6 mt-10 relative z-10">
          <div className="flex items-start mb-3">
            <div className="w-8 h-8 rounded-full bg-cyan-100 flex items-center justify-center mr-3 mt-1">
              <i className="fas fa-bolt text-cyan-600 text-xs"></i>
            </div>
            <div>
              <h4 className="font-semibold text-gray-800 mb-1">Emergency Consultant</h4>
              <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                Motivational Speaker & Business Consultant with a passion for building scalable technology solutions that empower businesses to achieve their potential.
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <div className="flex items-center text-green-700 bg-gradient-to-r from-green-50 to-green-100 px-4 py-3 rounded-xl border border-green-200">
            <div className="w-8 h-8 rounded-lg bg-green-100 flex items-center justify-center mr-3">
              <i className="fas fa-bullhorn text-green-600 text-sm"></i>
            </div>
            <div>
              <span className="text-sm font-bold text-gray-800">Motivational Speaker</span>
              <p className="text-green-600 text-xs">Inspirational Leadership</p>
            </div>
          </div>
          <div className="flex items-center text-cyan-700 bg-gradient-to-r from-cyan-50 to-cyan-100 px-4 py-3 rounded-xl border border-cyan-200">
            <div className="w-8 h-8 rounded-lg bg-cyan-100 flex items-center justify-center mr-3">
              <i className="fas fa-chart-line text-cyan-600 text-sm"></i>
            </div>
            <div>
              <span className="text-sm font-bold text-gray-800">Business Consultant</span>
              <p className="text-cyan-600 text-xs">Strategic Growth</p>
            </div>
          </div>
        </div>
      </div>

      {/* Philosophy Card */}
      <div className="bg-white rounded-3xl shadow-xl p-6 md:p-8 card-hover border-l-4 border-green-500 relative overflow-hidden">
        {/* Decorative corner */}
        <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-green-500/10 to-cyan-500/10 rounded-bl-3xl"></div>
        
        <div className="flex items-center mb-6 relative z-10">
          <div className="w-12 h-12 md:w-14 md:h-14 rounded-xl bg-gradient-to-r from-cyan-600 to-green-500 flex items-center justify-center mr-4 shadow-lg">
            <i className="fas fa-cogs text-white text-lg md:text-xl"></i>
          </div>
          <div>
            <h3 className="text-xl md:text-2xl font-bold text-gray-800">Engineering Philosophy</h3>
            <p className="text-green-600 text-sm">Core Principles & Values</p>
          </div>
        </div>
        
        <div className="space-y-4 md:space-y-5">
          <div className="flex items-start p-4 rounded-2xl bg-gradient-to-r from-cyan-50 to-white border border-cyan-100">
            <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-cyan-100 flex items-center justify-center mr-4">
              <i className="fas fa-handshake text-cyan-600"></i>
            </div>
            <div>
              <h4 className="font-bold text-gray-800 mb-1 flex items-center">
                Long-term Partnership Focus
                <span className="ml-2 px-2 py-0.5 bg-cyan-100 text-cyan-700 text-xs rounded-full">Priority</span>
              </h4>
              <p className="text-gray-600 text-sm">Over institutional relationships - building lasting connections and trust-based collaborations</p>
            </div>
          </div>
          
          <div className="flex items-start p-4 rounded-2xl bg-gradient-to-r from-green-50 to-white border border-green-100">
            <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center mr-4">
              <i className="fas fa-eye text-green-600"></i>
            </div>
            <div>
              <h4 className="font-bold text-gray-800 mb-1">Complete Transparency</h4>
              <p className="text-gray-600 text-sm">In communication and development - no hidden agendas, clear progress tracking</p>
            </div>
          </div>
          
          <div className="flex items-start p-4 rounded-2xl bg-gradient-to-r from-cyan-50 to-white border border-cyan-100">
            <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-cyan-100 flex items-center justify-center mr-4">
              <i className="fas fa-gem text-cyan-600"></i>
            </div>
            <div>
              <h4 className="font-bold text-gray-800 mb-1">Implementing Excellence</h4>
              <p className="text-gray-600 text-sm">And documented processes - quality at every step with measurable outcomes</p>
            </div>
          </div>
          
          <div className="flex items-start p-4 rounded-2xl bg-gradient-to-r from-green-50 to-white border border-green-100">
            <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center mr-4">
              <i className="fas fa-seedling text-green-600"></i>
            </div>
            <div>
              <h4 className="font-bold text-gray-800 mb-1">Ethical Business Practices</h4>
              <p className="text-gray-600 text-sm">And sustainable growth - doing business the right way with integrity</p>
            </div>
          </div>
        </div>
        
        {/* Quote Section */}
        <div className="mt-6 pt-6 border-t border-gray-100">
          <div className="flex items-center text-gray-500">
            <i className="fas fa-quote-left text-cyan-400 mr-2"></i>
            <p className="text-sm italic">"Engineering solutions that stand the test of time through principles and partnerships."</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

      {/* Stats Section */}
      <section className="py-5 px-4">
        <div className="max-w-6xl mx-auto">
          

          {/* CTA Section */}
          <div className="text-center">
            <button onClick={handleWhatsAppClick} className="bg-gradient-to-r from-cyan-600 to-green-500 text-white font-semibold py-4 px-12 rounded-xl hover:from-cyan-700 hover:to-green-600 transition-all duration-300 flex items-center justify-center mx-auto shadow-lg hover:shadow-xl hover:scale-[1.02]">
              <i className="fas fa-video mr-3"></i>
              Schedule Virtual Meeting
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default EngineerMethodology;