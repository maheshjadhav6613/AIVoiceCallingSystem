import React from 'react';

const EngineeredExcellence: React.FC = () => {


    const handleWhatsAppClick = () => {
    const whatsappNumber = "919146677505";
    const defaultMessage = encodeURIComponent("Hello! I'm interested in your MERN stack development services.   Explore Our Capabilities?");
    
    window.open(`https://wa.me/${whatsappNumber}?text=${defaultMessage}`, '_blank');
  };

  const handleCallClick = () => {
    window.location.href = 'tel:+919146677505';
  };

  return (
    <div className="min-h-screen bg-white">
      <style>{`
        .card-hover {
          transition: all 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
        }
        .cyan-gradient-text {
          background: linear-gradient(90deg, #06b6d4, #0891b2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .green-gradient-text {
          background: linear-gradient(90deg, #22c55e, #16a34a);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
      `}</style>
      
      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center px-4 py-12">
        <div className="max-w-6xl w-full">
          {/* Header */}
          <div className="text-center mb-5">
            <div className="inline-flex items-center px-5 py-3 rounded-full bg-white shadow-md border text-sm border-cyan-100 mb-2">
              <i className="fas fa-star text-green-500 mr-2"></i>
              <span className="text-cyan-700 font-medium">ENGINEERED EXCELLENCE FOR GLOBAL ENTERPRISE SUCCESS</span>
            </div>
            <h1 className="text-4xl md:text-4xl font-bold text-gray-800 mb-2 leading-tight">
              We Don't Just Build <span className="cyan-gradient-text">Websites</span>
            </h1>
            <p className="text-sm md:text-sm text-gray-600 max-w-4xl mx-auto leading-relaxed">
              We engineer digital ecosystems designed for scale, performance, and seamless user experiences.
            </p>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Pure MERN Expertise */}
            <div className="bg-white rounded-3xl p-8 shadow-xl border border-cyan-100 card-hover hover:shadow-2xl transition-all duration-300">
              <div className="flex items-center mb-6">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-r from-cyan-600 to-green-500 flex items-center justify-center mr-4 shadow-md">
                  <i className="fas fa-code text-white text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">Pure MERN Expertise</h2>
              </div>
              <p className="text-gray-600 mb-6">
                Specialized team with deep expertise in MongoDB, Express, React, and Node.js – the full stack that powers modern web applications.
              </p>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-cyan-600 mt-1 mr-3"></i>
                  <span className="text-gray-700">Designed MongoDB specialists</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                  <span className="text-gray-700">React & Node.js optimization</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-cyan-600 mt-1 mr-3"></i>
                  <span className="text-gray-700">Express architecture experts</span>
                </li>
              </ul>
            </div>

            {/* Global Delivery Experience */}
            <div className="bg-white rounded-3xl p-8 shadow-xl border border-green-100 card-hover hover:shadow-2xl transition-all duration-300">
              <div className="flex items-center mb-6">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-r from-cyan-600 to-green-500 flex items-center justify-center mr-4 shadow-md">
                  <i className="fas fa-globe text-white text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">Global Delivery Experience</h2>
              </div>
              <p className="text-gray-600 mb-6">
                Proven track record delivering enterprise solutions across India, Dubai, Singapore, and the UK with precision and excellence.
              </p>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                  <span className="text-gray-700">Multi-emergence collaboration</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-cyan-600 mt-1 mr-3"></i>
                  <span className="text-gray-700">International compliance expertise</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                  <span className="text-gray-700">Cross-cultural UK understanding</span>
                </li>
              </ul>
            </div>

            {/* Strategic Engineering Team */}
            <div className="bg-white rounded-3xl p-8 shadow-xl border border-cyan-100 card-hover hover:shadow-2xl transition-all duration-300">
              <div className="flex items-center mb-6">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-r from-cyan-600 to-green-500 flex items-center justify-center mr-4 shadow-md">
                  <i className="fas fa-users text-white text-xl"></i>
                </div>
                <h2 className="text-2xl font-bold text-gray-800">Strategic Engineering Team</h2>
              </div>
              <p className="text-gray-600 mb-6">
                A 50-member team with 44 specialized developers structured for efficient collaboration and technical excellence.
              </p>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-cyan-600 mt-1 mr-3"></i>
                  <span className="text-gray-700">Specialized frontend developers</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                  <span className="text-gray-700">Disciplined business architects</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-cyan-600 mt-1 mr-3"></i>
                  <span className="text-gray-700">Professional project managers</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Stats Section */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-5">
            <div className="bg-white rounded-2xl p-6 text-center shadow-lg border border-cyan-100 hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-cyan-100 to-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-sm">
                <i className="fas fa-user-tie text-cyan-600 text-2xl"></i>
              </div>
              <p className="text-3xl font-bold text-gray-800">50+</p>
              <p className="text-gray-600">Team Members</p>
            </div>
            <div className="bg-white rounded-2xl p-6 text-center shadow-lg border border-green-100 hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-green-100 to-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-sm">
                <i className="fas fa-code text-green-600 text-2xl"></i>
              </div>
              <p className="text-3xl font-bold text-gray-800">44</p>
              <p className="text-gray-600">Specialized Developers</p>
            </div>
            <div className="bg-white rounded-2xl p-6 text-center shadow-lg border border-cyan-100 hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-cyan-100 to-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-sm">
                <i className="fas fa-map-marker-alt text-cyan-600 text-2xl"></i>
              </div>
              <p className="text-3xl font-bold text-gray-800">4</p>
              <p className="text-gray-600">Countries Served</p>
            </div>
            <div className="bg-white rounded-2xl p-6 text-center shadow-lg border border-green-100 hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-green-100 to-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-sm">
                <i className="fas fa-rocket text-green-600 text-2xl"></i>
              </div>
              <p className="text-3xl font-bold text-gray-800">98%</p>
              <p className="text-gray-600">Client Satisfaction</p>
            </div>
          </div>

          {/* CTA Section */}
          <div className="text-center mt-5">
            <button onClick={handleWhatsAppClick} className="bg-gradient-to-r from-cyan-600 to-green-500 text-white font-semibold py-4 px-12 rounded-xl hover:from-cyan-700 hover:to-green-600 transition-all duration-300 flex items-center justify-center mx-auto shadow-xl hover:shadow-2xl text-lg hover:scale-[1.02]">
              <i className="fas fa-compass mr-3"></i>
              Explore Our Capabilities
            </button>
          </div>

          {/* Additional Info */}
          <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-gradient-to-r from-white to-cyan-50 rounded-2xl p-6 border border-cyan-100">
              <h3 className="text-lg font-bold text-gray-800 mb-3 flex items-center">
                <i className="fas fa-bullseye text-cyan-600 mr-2"></i>
                Our Mission
              </h3>
              <p className="text-gray-600">
                To deliver scalable, high-performance digital solutions that drive measurable business growth and exceed client expectations.
              </p>
            </div>
            <div className="bg-gradient-to-r from-white to-green-50 rounded-2xl p-6 border border-green-100">
              <h3 className="text-lg font-bold text-gray-800 mb-3 flex items-center">
                <i className="fas fa-chart-line text-green-600 mr-2"></i>
                Growth Focused
              </h3>
              <p className="text-gray-600">
                Every solution is engineered with scalability in mind, ensuring your digital presence grows alongside your business.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default EngineeredExcellence;