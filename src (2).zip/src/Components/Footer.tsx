import React from 'react';

const Footer: React.FC = () => {
  return (
    <div className="w-full max-w-6xl mx-auto">
      {/* Footer Section */}
      <footer className="bg-white rounded-3xl shadow-2xl overflow-hidden">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 p-8 md:p-12">
          {/* Brand Column */}
          <div className="space-y-6">
            <div className="flex items-center">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-100 to-white flex items-center justify-center mr-4 shadow-sm">
                <i className="fas fa-code text-cyan-600 text-xl"></i>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-800">ARRCTECHIE</h2>
                <p className="text-cyan-600 font-medium">MERN Stack Specialists</p>
              </div>
            </div>
            
            <p className="text-gray-600 leading-relaxed text-sm">
              Engineering scalable, modern digital products using MERN technology. Trusted by global businesses for quality, reliability, and long-term support.
            </p>

            {/* Trust Badges */}
            <div className="flex flex-wrap gap-3">
              <div className="bg-cyan-50 text-cyan-700 px-3 py-1 rounded-full text-sm font-medium">
                <i className="fas fa-shield-check mr-1"></i>
                Trusted
              </div>
              <div className="bg-green-50 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                <i className="fas fa-globe mr-1"></i>
                Global
              </div>
              <div className="bg-cyan-50 text-cyan-700 px-3 py-1 rounded-full text-sm font-medium">
                <i className="fas fa-infinity mr-1"></i>
                Support
              </div>
            </div>
          </div>

          {/* Services Column */}
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-gray-800 flex items-center">
              <i className="fas fa-cogs text-green-500 mr-3"></i>
              Services
            </h3>
            <div className="space-y-3">
              <div className="footer-link flex items-center text-gray-600 cursor-pointer hover:text-cyan-600 transition-colors duration-300">
                <i className="fas fa-chevron-right text-cyan-600 text-xs mr-3"></i>
                <span className="text-sm">Website Development</span>
              </div>
              <div className="footer-link flex items-center text-gray-600 cursor-pointer hover:text-cyan-600 transition-colors duration-300">
                <i className="fas fa-chevron-right text-cyan-600 text-xs mr-3"></i>
                <span className="text-sm">Web Applications</span>
              </div>
              <div className="footer-link flex items-center text-gray-600 cursor-pointer hover:text-green-600 transition-colors duration-300">
                <i className="fas fa-chevron-right text-green-600 text-xs mr-3"></i>
                <span className="text-sm">MERN Stack Development</span>
              </div>
              <div className="footer-link flex items-center text-gray-600 cursor-pointer hover:text-cyan-600 transition-colors duration-300">
                <i className="fas fa-chevron-right text-cyan-600 text-xs mr-3"></i>
                <span className="text-sm">Custom Software</span>
              </div>
              <div className="footer-link flex items-center text-gray-600 cursor-pointer hover:text-green-600 transition-colors duration-300">
                <i className="fas fa-chevron-right text-green-600 text-xs mr-3"></i>
                <span className="text-sm">API Development</span>
              </div>
            </div>
          </div>

          {/* Contact Column */}
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-gray-800 flex items-center">
              <i className="fas fa-envelope text-cyan-600 mr-3"></i>
              Contact
            </h3>
            <div className="space-y-4">
              <div className="flex items-center text-gray-600">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-100 to-white flex items-center justify-center mr-4 shadow-sm">
                  <i className="fas fa-phone text-green-600"></i>
                </div>
                <div>
                  <p className="font-semibold text-sm">+91 91466 77505</p>
                  <p className="text-xs text-gray-500">Call us anytime</p>
                </div>
              </div>
              
              <div className="flex items-center text-gray-600">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-100 to-white flex items-center justify-center mr-4 shadow-sm">
                  <i className="fas fa-envelope text-cyan-600"></i>
                </div>
                <div>
                  <p className="font-semibold text-sm">mahendra@arrctechie.digital</p>
                  <p className="text-xs text-gray-500">Email us</p>
                </div>
              </div>
              
              <div className="flex items-center text-gray-600">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-100 to-white flex items-center justify-center mr-4 shadow-sm">
                  <i className="fas fa-map-marker-alt text-green-600"></i>
                </div>
                <div>
                  <p className="font-semibold text-sm">Pune, Maharashtra, India</p>
                  <p className="text-xs text-gray-500">Headquarters</p>
                </div>
              </div>
            </div>

            {/* Social Links */}
        
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="bg-gradient-to-r from-cyan-600 to-green-500 text-white py-6 px-8 md:px-12">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="flex items-center">
              <i className="fas fa-copyright text-green-300 mr-2"></i>
              <span className="text-sm md:text-base">2025 ARRCTECHIE. All rights reserved.</span>
            </div>
           
          </div>

          {/* Additional Info */}
          <div className="mt-4 pt-4  text-center md:text-left">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-cyan-100">
              <div className="flex items-center justify-center md:justify-start">
                <i className="fas fa-clock mr-2"></i>
                <span>24/8 Technical Support Available</span>
              </div>
              <div className="flex items-center justify-center md:justify-start">
                <i className="fas fa-shield-alt mr-2"></i>
                <span>ISO 27001 Security Standards</span>
              </div>
              <div className="flex items-center justify-center md:justify-start">
                <i className="fas fa-globe mr-2"></i>
                <span>Serving Clients Worldwide</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Footer;