import React from 'react';

const Index: React.FC = () => {

  const handleWhatsAppClick = () => {
    const whatsappNumber = "919146677505";
    const defaultMessage = encodeURIComponent("Hello! I'm interested in your MERN stack development services.  Schedule Free Consultation?");
    
    window.open(`https://wa.me/${whatsappNumber}?text=${defaultMessage}`, '_blank');
  };

  const handleCallClick = () => {
    window.location.href = 'tel:+919146677505';
  };


  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <style>{`
        body {
          font-family: 'Inter', sans-serif;
          background: linear-gradient(135deg, #f0fdfa 0%, #f0fdf4 100%);
        }
        .cyan-green-gradient {
          background: linear-gradient(135deg, #0891b2 0%, #22c55e 100%);
        }
        .card-hover {
          transition: all 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
        }
        .cyan-gradient-text {
          background: linear-gradient(90deg, #06b6d4, #0891b2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .green-gradient-text {
          background: linear-gradient(90deg, #22c55e, #16a34a);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .floating {
          animation: floating 3s ease-in-out infinite;
        }
        @keyframes floating {
          0% { transform: translate(0, 0px); }
          50% { transform: translate(0, -10px); }
          100% { transform: translate(0, 0px); }
        }
      `}</style>
      
      <div className="max-w-6xl w-full">
        {/* Header Section */}
        <div className="text-center mb-5">
          <div className="inline-flex items-center px-5 py-3 rounded-full bg-white shadow-md text-sm border border-cyan-100 mb-5">
            <i className="fas fa-star text-green-500 mr-2"></i>
            <span className="text-cyan-700 font-medium">TRUSTED BY GLOBAL BUSINESSES SINCE 2017</span>
          </div>
          <h1 className="text-4xl md:text-4xl font-bold text-gray-800 mb-1">
            Enterprise-Level <span className="cyan-gradient-text">Web Development</span>
          </h1>
          <p className="text-gray-600 text-sm max-w-2xl mx-auto">Building modern digital solutions for tomorrow's businesses</p>
        </div>

        {/* Main Content Card */}
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
          <div className="flex flex-col lg:flex-row">
            {/* Left Content Section */}
            <div className="lg:w-1/2 p-10 lg:p-12 flex flex-col justify-center">
              {/* Stats Cards */}
            <div className="grid grid-cols-2 gap-5 mb-8">

  {/* Experience Card */}
  <div className="bg-gradient-to-br from-cyan-50 to-green-50 rounded-2xl p-5 border border-cyan-100 card-hover">
    <div className="flex flex-col md:flex-row items-center text-center md:text-left md:justify-center">
      <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-cyan-600 to-green-500 text-center flex items-center justify-center md:mr-4 shadow-md">
        <i className="fas fa-calendar-alt text-white"></i>
      </div>
      <div>
        <p className="text-2xl font-bold text-gray-800">7+</p>
        <p className="text-sm text-gray-600">Years Experience</p>
      </div>
    </div>
  </div>

  {/* Team Members Card */}
  <div className="bg-gradient-to-br from-green-50 to-cyan-50 rounded-2xl p-5 border border-green-100 card-hover">
    <div className="flex flex-col md:flex-row items-center text-center md:text-left md:justify-center">
      <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-cyan-600 to-green-500 flex items-center justify-center md:mr-4 shadow-md">
        <i className="fas fa-users text-white"></i>
      </div>
      <div>
        <p className="text-2xl font-bold text-gray-800">50+</p>
        <p className="text-sm text-gray-600">Team Members</p>
      </div>
    </div>
  </div>

</div>


              {/* Project Range */}
              <div className="mb-8">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 rounded-full bg-cyan-100 flex items-center justify-center mr-4">
                    <i className="fas fa-chart-line text-cyan-600"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800">Project Range</h3>
                    <p className="text-gray-600">from 20,000 to 45,000</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-4">
                    <i className="fas fa-globe-americas text-green-600"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800">Global Presence</h3>
                    <p className="text-gray-600">India, Dubai, Singapore & UK</p>
                  </div>
                </div>
              </div>

              {/* CTA Section */}
              <div className="space-y-6">
                <button onClick={handleWhatsAppClick} className="w-full bg-gradient-to-r from-cyan-600 to-green-500 text-white font-semibold py-4 px-8 rounded-xl hover:from-cyan-700 hover:to-green-600 transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl hover:scale-[1.02]">
                  <i className="fas fa-calendar-check mr-3"></i>
                  Schedule Free Consultation
                </button>
                
                {/* Experience Badge */}
                <div className="flex items-center justify-center bg-gradient-to-r from-white to-green-50 rounded-2xl p-5 border border-green-100">
                  <div className="bg-gradient-to-r from-cyan-600 to-green-500 rounded-full p-3 shadow-lg mr-4">
                    <span className="text-xl font-bold text-white">7+</span>
                  </div>
                  <div className="text-center">
                    <p className="text-gray-800 font-bold">Years of Excellence</p>
                    <p className="text-gray-600 text-sm">Delivering exceptional results   </p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Right Image Section */}
            <div className="lg:w-1/2 relative bg-gradient-to-br from-cyan-600 to-green-500">
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-0 right-0 w-80 h-80 bg-white rounded-full -mr-40 -mt-40"></div>
                <div className="absolute bottom-0 left-0 w-80 h-80 bg-white rounded-full -ml-40 -mb-40"></div>
              </div>
              
              {/* Content Container */}
              <div className="relative z-10 h-full flex flex-col items-center justify-center text-center p-10">
                {/* Main Image Placeholder */}
                <div className="w-72 h-72 rounded-3xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center mb-8 shadow-2xl floating">
                  <div className="w-60 h-60 rounded-2xl bg-white/30 flex items-center justify-center">
                    <div className="w-52 h-52 rounded-2xl bg-white/40 flex items-center justify-center">
                      <img src="/image2.png" alt="" className='rounded-2xl'/>
                    </div>
                  </div>
                </div>
                
                <h3 className="text-3xl font-bold text-white mb-4 uppercase">Arrc Techie Solutions</h3>
                <p className="text-cyan-100 mb-8 max-w-md">Cutting-edge technology solutions tailored to your business needs</p>
              </div>
              
              {/* Floating Elements */}
              <div className="absolute top-8 left-8 w-14 h-14 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30 floating" style={{ animationDelay: '0.5s' }}>
                <i className="fab fa-react text-white text-xl"></i>
              </div>
              <div className="absolute bottom-8 right-8 w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30 floating" style={{ animationDelay: '1s' }}>
                <i className="fab fa-node-js text-white text-xl"></i>
              </div>
              <div className="absolute top-1/2 right-20 w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30 floating" style={{ animationDelay: '1.5s' }}>
                <i className="fas fa-mobile-alt text-white"></i>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-4">
          <div className="bg-white rounded-2xl p-6 text-center shadow-md border border-cyan-100 hover:shadow-lg transition-shadow duration-300">
            <div className="w-12 h-12 bg-gradient-to-br from-cyan-100 to-white rounded-xl flex items-center justify-center mx-auto mb-3">
              <i className="fas fa-project-diagram text-cyan-600"></i>
            </div>
            <p className="text-2xl font-bold text-gray-800">200+</p>
            <p className="text-gray-600">Projects Completed</p>
          </div>
          <div className="bg-white rounded-2xl p-6 text-center shadow-md border border-green-100 hover:shadow-lg transition-shadow duration-300">
            <div className="w-12 h-12 bg-gradient-to-br from-green-100 to-white rounded-xl flex items-center justify-center mx-auto mb-3">
              <i className="fas fa-smile text-green-600"></i>
            </div>
            <p className="text-2xl font-bold text-gray-800">98%</p>
            <p className="text-gray-600">Client Satisfaction</p>
          </div>
          <div className="bg-white rounded-2xl p-6 text-center shadow-md border border-cyan-100 hover:shadow-lg transition-shadow duration-300">
            <div className="w-12 h-12 bg-gradient-to-br from-cyan-100 to-white rounded-xl flex items-center justify-center mx-auto mb-3">
              <i className="fas fa-clock text-cyan-600"></i>
            </div>
            <p className="text-2xl font-bold text-gray-800">24/7</p>
            <p className="text-gray-600">Support Available</p>
          </div>
          <div className="bg-white rounded-2xl p-6 text-center shadow-md border border-green-100 hover:shadow-lg transition-shadow duration-300">
            <div className="w-12 h-12 bg-gradient-to-br from-green-100 to-white rounded-xl flex items-center justify-center mx-auto mb-3">
              <i className="fas fa-award text-green-600"></i>
            </div>
            <p className="text-2xl font-bold text-gray-800">15+</p>
            <p className="text-gray-600">Industry Awards</p>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="flex flex-wrap justify-center gap-4 mt-5">
          <div className="bg-gradient-to-r from-cyan-50 to-green-50 px-4 py-2 rounded-full border border-cyan-200 flex items-center">
            <i className="fas fa-shield-alt text-cyan-600 mr-2"></i>
            <span className="text-gray-700 text-sm">ISO Certified</span>
          </div>
          <div className="bg-gradient-to-r from-green-50 to-cyan-50 px-4 py-2 rounded-full border border-green-200 flex items-center">
            <i className="fas fa-bolt text-green-600 mr-2"></i>
            <span className="text-gray-700 text-sm">24/7 Support</span>
          </div>
          <div className="bg-gradient-to-r from-cyan-50 to-green-50 px-4 py-2 rounded-full border border-cyan-200 flex items-center">
            <i className="fas fa-lock text-cyan-600 mr-2"></i>
            <span className="text-gray-700 text-sm">Data Secure</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;