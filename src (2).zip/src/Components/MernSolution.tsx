import React from 'react';

const MernSolution: React.FC = () => {

  const handleWhatsAppClick = () => {
    const whatsappNumber = "919146677505";
    const defaultMessage = encodeURIComponent("Hello! I'm interested in your MERN stack development services.  Request Detailed Proposal");
    
    window.open(`https://wa.me/${whatsappNumber}?text=${defaultMessage}`, '_blank');
  };

 
 
  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-50/30 to-green-50/30">
      <style>{`
        .card-hover {
          transition: all 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-8px);
          box-shadow: 0 20px 40px -15px rgba(6, 182, 212, 0.2);
        }
        .cyan-gradient-text {
          background: linear-gradient(90deg, #06b6d4, #0891b2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .green-gradient-text {
          background: linear-gradient(90deg, #22c55e, #16a34a);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .service-card {
          border-left-width: 4px;
          transition: all 0.3s ease;
        }
      `}</style>
      
      {/* Header Section */}
      <section className="pt-16 pb-5 px-4">
        <div className="max-w-6xl mx-auto text-center">
             <div className="inline-flex items-center px-5 py-3 rounded-full bg-white shadow-md border text-sm border-cyan-100 mb-2">
            <i className="fas fa-shield-alt text-cyan-600 mr-2"></i>
            <span className="text-cyan-700 text-sm ">ENTERPRISE-GRADE MERN SOLUTIONS</span>
            </div>
          
         
          <h1 className="text-4xl md:text-4xl font-bold text-gray-800 mb-3 leading-tight">
            Professional Development with 
            <span className="cyan-gradient-text"> Transparency</span>
          </h1>
          <p className="text-sm text-gray-600 max-w-3xl mx-auto leading-relaxed">
            We deliver documented processes ensuring your digital assets are built to enterprise standards.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-5 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            
            {/* Website Development */}
            <div className="bg-white rounded-2xl shadow-xl service-card border-l-cyan-500 card-hover overflow-hidden">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-globe text-cyan-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800">Website Development</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  High-performance, responsive websites built on modern frameworks that elevate your brand and drive conversions.
                </p>
                <div className="price-tag bg-gradient-to-r from-cyan-50 to-green-50 rounded-xl p-4 border border-cyan-100">
                  <p className="text-sm text-gray-600 mb-1">Starting from</p>
                  <p className="text-2xl font-bold text-gray-800">₹20,000</p>
                </div>
              </div>
            </div>

            {/* Web Application Development */}
            <div className="bg-white rounded-2xl shadow-xl service-card border-l-green-500 card-hover overflow-hidden">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-layer-group text-green-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800">Web Application Development</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Complex, scalable web applications with rich interfaces and powerful backend systems for enterprise needs.
                </p>
                <div className="price-tag bg-gradient-to-r from-green-50 to-cyan-50 rounded-xl p-4 border border-green-100">
                  <p className="text-sm text-gray-600 mb-1">Starting from</p>
                  <p className="text-2xl font-bold text-gray-800">₹2,00,000</p>
                </div>
              </div>
            </div>

            {/* MERN Stack Development */}
            <div className="bg-white rounded-2xl shadow-xl service-card border-l-cyan-500 card-hover overflow-hidden">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-code text-cyan-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800">MERN Stack Development</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Full-stack solutions leveraging MongoDB, Express, React, and Node.js for modern, scalable applications.
                </p>
                <div className="price-tag bg-gradient-to-r from-cyan-50 to-green-50 rounded-xl p-4 border border-cyan-100">
                  <p className="text-sm text-gray-600 mb-1">Starting from</p>
                  <p className="text-2xl font-bold text-gray-800">₹3,50,000</p>
                </div>
              </div>
            </div>

            {/* Custom Software Solutions */}
            <div className="bg-white rounded-2xl shadow-xl service-card border-l-green-500 card-hover overflow-hidden">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-cogs text-green-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800">Custom Software Solutions</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Tailored software development addressing specific business challenges with innovative, scalable solutions.
                </p>
                <div className="price-tag bg-gradient-to-r from-green-50 to-cyan-50 rounded-xl p-4 border border-green-100">
                  <p className="text-sm text-gray-600 mb-1">Starting from</p>
                  <p className="text-2xl font-bold text-gray-800">₹5,00,000</p>
                </div>
              </div>
            </div>

            {/* API Development & Integrations */}
            <div className="bg-white rounded-2xl shadow-xl service-card border-l-cyan-500 card-hover overflow-hidden">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-plug text-cyan-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800">API Development & Integrations</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Robust API development and seamless third-party integrations for connected business ecosystems.
                </p>
                <div className="price-tag bg-gradient-to-r from-cyan-50 to-green-50 rounded-xl p-4 border border-cyan-100">
                  <p className="text-sm text-gray-600 mb-1">Starting from</p>
                  <p className="text-2xl font-bold text-gray-800">₹1,50,000</p>
                </div>
              </div>
            </div>

            {/* UI/UX Frontend Engineering */}
            <div className="bg-white rounded-2xl shadow-xl service-card border-l-green-500 card-hover overflow-hidden">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-100 to-white flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-palette text-green-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800">UI/UX Frontend Engineering</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Human-centered design with exceptional UI/UX implementation for intuitive and engaging digital experiences.
                </p>
                <div className="price-tag bg-gradient-to-r from-green-50 to-cyan-50 rounded-xl p-4 border border-green-100">
                  <p className="text-sm text-gray-600 mb-1">Starting from</p>
                  <p className="text-2xl font-bold text-gray-800">₹1,00,000</p>
                </div>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="text-center mt-5 ">
            <button onClick={handleWhatsAppClick} className=" w-80 bg-gradient-to-r from-cyan-600 to-green-500 text-white font-semibold py-4 px-12 rounded-xl hover:from-cyan-700 hover:to-green-600 transition-all duration-300 flex items-center justify-center mx-auto shadow-xl hover:shadow-2xl text-lg hover:scale-[1.02]">
              <i className="fas fa-file-contract mr-3"></i>
              Request Detailed Proposal
            </button>
            
          </div>
        </div>
      </section>
    </div>
  );
};

export default MernSolution;