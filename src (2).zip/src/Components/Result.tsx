import React from 'react';

const Result: React.FC = () => {

  const handleWhatsAppClick = () => {
    const whatsappNumber = "919146677505";
    const defaultMessage = encodeURIComponent("Hello! I'm interested in your MERN stack development services. Can we discuss my project?");
    
    window.open(`https://wa.me/${whatsappNumber}?text=${defaultMessage}`, '_blank');
  };

  const handleCallClick = () => {
    window.location.href = 'tel:+919146677505';
  };



  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-cyan-50/30 to-green-50/30 py-8">
      <style>
        {`
        .cyan-gradient-text {
          background: linear-gradient(90deg, #06b6d4, #0891b2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .card-hover {
          transition: all 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-8px);
          box-shadow: 0 20px 40px -15px rgba(6, 182, 212, 0.15);
        }
        `}
      </style>
      
      {/* Header Section */}
      <section className="pb-5 px-4 flex-shrink-0">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-white shadow-md border border-cyan-100 mb-2">
            <i className="fas fa-chart-line text-green-500 mr-2 text-sm"></i>
            <span className="text-cyan-700 text-sm">RESULTS THAT SPEAK VOLUMES</span>
          </div>
          <h1 className="text-4xl md:text-4xl font-bold text-gray-800 mb-2 leading-tight">
            Measurable <span className="cyan-gradient-text">Business Impact</span>
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto text-sm">
            Our work has delivered measurable results for businesses across industries and geographies.
          </p>
        </div>
      </section>

      {/* Scrollable Content */}
      <div className="px-4 flex-grow overflow-y-auto">
        <div className="max-w-6xl mx-auto pb-8">
          
          {/* E-Commerce Case Study */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-6 card-hover border border-cyan-100">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              {/* Left Content */}
              
              <div className="bg-gradient-to-br from-cyan-600 to-green-500 p-6 flex flex-col justify-center text-white">
                <div className="text-center mb-6">
                  <div className="text-3xl font-bold mb-1">43%</div>
                  <div className="text-lg font-semibold mb-1">Revenue Increase</div>
                  <p className="text-cyan-100 text-xs opacity-90">Improved conversion funnels</p>
                </div>
                 {/* Right Stats */}
                <div className="text-center">
                  <div className="text-3xl font-bold mb-1">99.98%</div>
                  <div className="text-lg font-semibold mb-1">Uptime</div>
                  <p className="text-cyan-100 text-xs opacity-90">Robust infrastructure</p>
                </div>
              </div>
              
              
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-100 to-white flex items-center justify-center mr-3 shadow-sm">
                    <i className="fas fa-shopping-cart text-green-600"></i>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-800">E-Commerce</h3>
                    <p className="text-gray-600 text-sm">Multi-vendor Marketplace</p>
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="inline-flex items-center px-3 py-1 bg-cyan-50 rounded-full text-cyan-700 text-xs font-medium">
                    <i className="fas fa-user-tie mr-1"></i>
                    Babel-based Client
                  </div>
                </div>

                {/* Results Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="result-badge bg-gradient-to-r from-cyan-50 to-green-50 rounded-xl p-4 border border-cyan-100">
                    <div className="text-2xl font-bold text-gray-800 mb-1">400%</div>
                    <div className="text-sm font-semibold text-gray-700 mb-1">Faster Load Speed</div>
                    <p className="text-xs text-gray-600">Optimized React & MongoDB</p>
                  </div>
                  <div className="result-badge bg-gradient-to-r from-green-50 to-cyan-50 rounded-xl p-4 border border-green-100">
                    <div className="text-2xl font-bold text-gray-800 mb-1">78%</div>
                    <div className="text-sm font-semibold text-gray-700 mb-1">User Engagement</div>
                    <p className="text-xs text-gray-600">Improved UX & visualization</p>
                  </div>
                </div>

                {/* Tech Stack */}
                <div className="mb-4">
                  <h4 className="text-sm font-bold text-gray-800 mb-2">Tech Stack</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="tech-stack-item flex items-center">
                      <i className="fab fa-react text-cyan-600 mr-2 text-sm"></i>
                      <span className="text-gray-700">React</span>
                    </div>
                    <div className="tech-stack-item flex items-center">
                      <i className="fas fa-database text-cyan-600 mr-2 text-sm"></i>
                      <span className="text-gray-700">MongoDB</span>
                    </div>
                    <div className="tech-stack-item flex items-center">
                      <i className="fab fa-node-js text-green-600 mr-2 text-sm"></i>
                      <span className="text-gray-700">Node.js</span>
                    </div>
                    <div className="tech-stack-item flex items-center">
                      <i className="fas fa-server text-green-600 mr-2 text-sm"></i>
                      <span className="text-gray-700">Express</span>
                    </div>
                  </div>
                </div>
              </div>

             
            </div>
          </div>

          {/* FinTech Case Study */}
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-6 card-hover border border-cyan-100">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              {/* Left Content */}
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-100 to-white flex items-center justify-center mr-3 shadow-sm">
                    <i className="fas fa-chart-line text-cyan-700"></i>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-800">FinTech</h3>
                    <p className="text-gray-600 text-sm">Investment Portfolio System</p>
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="inline-flex items-center px-3 py-1 bg-green-50 rounded-full text-green-700 text-xs font-medium">
                    <i className="fas fa-flag-uk mr-1"></i>
                    UK-based Client
                  </div>
                </div>

                {/* Results Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="result-badge bg-gradient-to-r from-cyan-50 to-green-50 rounded-xl p-4 border border-cyan-100">
                    <div className="flex items-center mb-2">
                      <i className="fas fa-shield-alt text-cyan-600 mr-2"></i>
                      <div className="text-sm font-semibold text-gray-700">GDPR & FCA Compliant</div>
                    </div>
                    <p className="text-xs text-gray-600">Enterprise security & compliance</p>
                  </div>
                  <div className="result-badge bg-gradient-to-r from-green-50 to-cyan-50 rounded-xl p-4 border border-green-100">
                    <div className="text-2xl font-bold text-gray-800 mb-1">65%</div>
                    <div className="text-sm font-semibold text-gray-700 mb-1">Process Automation</div>
                    <p className="text-xs text-gray-600">Reduced manual operations</p>
                  </div>
                </div>

                {/* Tech Stack */}
                <div className="mb-4">
                  <h4 className="text-sm font-bold text-gray-800 mb-2">Tech Stack</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="tech-stack-item flex items-center">
                      <i className="fas fa-server text-cyan-600 mr-2 text-sm"></i>
                      <span className="text-gray-700">MongoDB</span>
                    </div>
                    <div className="tech-stack-item flex items-center">
                      <i className="fab fa-react text-cyan-600 mr-2 text-sm"></i>
                      <span className="text-gray-700">React</span>
                    </div>
                    <div className="tech-stack-item flex items-center">
                      <i className="fab fa-node-js text-green-600 mr-2 text-sm"></i>
                      <span className="text-gray-700">Node.js</span>
                    </div>
                    <div className="tech-stack-item flex items-center">
                      <i className="fas fa-code text-green-600 mr-2 text-sm"></i>
                      <span className="text-gray-700">API5</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Stats */}
              <div className="bg-gradient-to-br from-green-500 to-cyan-600 p-6 flex flex-col justify-center text-white">
                <div className="text-center">
                  <div className="w-16 h-16 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-lock text-2xl text-gray-500"></i>
                  </div>
                  <h4 className="text-lg font-bold mb-2">Enterprise Security</h4>
                  <p className="text-green-100 text-xs mb-4 opacity-90">Bank-level security protocols</p>
                  
                  <div className="flex justify-center space-x-4">
                    <div className="text-center">
                      <div className="text-lg font-bold">100%</div>
                      <div className="text-xs">Encryption</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold">24/8</div>
                      <div className="text-xs">Monitoring</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold">SLA</div>
                      <div className="text-xs">Guarantee</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Info Section */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <div className="bg-white rounded-xl p-5 border border-cyan-100 shadow-sm">
              <div className="flex items-center mb-3">
                <div className="w-10 h-10 rounded-lg bg-cyan-50 flex items-center justify-center mr-3">
                  <i className="fas fa-bolt text-cyan-600"></i>
                </div>
                <h4 className="font-bold text-gray-800">Fast Delivery</h4>
              </div>
              <p className="text-sm text-gray-600">Average project completion 30% faster than industry standards</p>
            </div>
            
            <div className="bg-white rounded-xl p-5 border border-green-100 shadow-sm">
              <div className="flex items-center mb-3">
                <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center mr-3">
                  <i className="fas fa-heart text-green-600"></i>
                </div>
                <h4 className="font-bold text-gray-800">Client Satisfaction</h4>
              </div>
              <p className="text-sm text-gray-600">98% client retention rate with glowing testimonials</p>
            </div>
            
            <div className="bg-white rounded-xl p-5 border border-cyan-100 shadow-sm">
              <div className="flex items-center mb-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-50 to-green-50 flex items-center justify-center mr-3">
                  <i className="fas fa-award text-cyan-600"></i>
                </div>
                <h4 className="font-bold text-gray-800">Quality Assurance</h4>
              </div>
              <p className="text-sm text-gray-600">Rigorous testing ensuring 99.9% bug-free delivery</p>
            </div>
          </div>

          {/* CTA */}
          <div className="text-center mt-8">
            <a href='/Propasal.pdf' download className="w-80 bg-gradient-to-r from-cyan-600 to-green-500 text-white font-semibold py-3 px-8 rounded-xl hover:from-cyan-700 hover:to-green-600 transition-all duration-300 flex items-center justify-center mx-auto shadow-lg hover:shadow-xl hover:scale-[1.02]">
              <i className="fas fa-chart-bar mr-2"></i>
              View More Case Studies
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Result;