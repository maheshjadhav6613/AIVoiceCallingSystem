import React, { useEffect } from 'react';

const Technical: React.FC = () => {










  useEffect(() => {
    // Animate skill bars on scroll
    const skillBars = document.querySelectorAll('.skill-progress');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const target = entry.target as HTMLElement;
          const width = target.style.width;
          target.style.width = '0%';
          setTimeout(() => {
            target.style.width = width;
          }, 100);
        }
      });
    }, { threshold: 0.5 });

    skillBars.forEach(bar => observer.observe(bar));

    // Cleanup observer on component unmount
    return () => {
      skillBars.forEach(bar => observer.unobserve(bar));
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-cyan-50/20 to-green-50/20">
      <style>{`
        .card-hover {
          transition: all 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
        }
        .cyan-gradient-text {
          background: linear-gradient(90deg, #06b6d4, #0891b2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .skill-bar {
          height: 10px;
          background-color: #e5e7eb;
          border-radius: 10px;
          overflow: hidden;
        }
        .skill-progress {
          height: 100%;
          border-radius: 10px;
          transition: width 1.5s ease-in-out;
        }
        .tech-tag {
          background: white;
          padding: 10px 20px;
          border-radius: 50px;
          display: flex;
          align-items: center;
          border: 1px solid #d1d5db;
          transition: all 0.3s ease;
          font-weight: 500;
        }
        .tech-tag:hover {
          transform: translateY(-3px);
          box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
      `}</style>

      {/* Header Section */}
      <section className="pt-5 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center px-5 py-3 rounded-full bg-white shadow-lg border border-cyan-100 mb-3">
            <i className="fas fa-laptop-code text-green-500 mr-2"></i>
            <span className="text-cyan-700">TECHNICAL EXPERTISE</span>
          </div>
          <h1 className="text-4xl md:text-4xl font-bold text-gray-800 mb-2 leading-tight">
            Deep <span className="cyan-gradient-text">Technical</span> Specialization
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Our deep specialization in modern web technologies enables us to build robust, scalable solutions for enterprise needs.
          </p>
        </div>
      </section>

      {/* MERN Stack Section */}
      <section className="pt-5 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="bg-white rounded-3xl shadow-xl p-8 mb-5 card-hover border-t-4 border-cyan-500">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">MERN Stack Specialization</h2>
              <p className="text-gray-600 max-w-3xl mx-auto">
                Our core expertise lies in the MERN technology stack, which provides a powerful, flexible foundation for modern web applications. We've refined our development approach across hundreds of projects to maximize the benefits of this stack.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* MongoDB */}
              <div className="bg-gradient-to-br from-cyan-50 to-green-50 rounded-2xl p-6 border border-cyan-100 card-hover">
                <div className="w-16 h-16 rounded-2xl bg-cyan-100 flex items-center justify-center mb-4 shadow-sm">
                  <i className="fas fa-database text-cyan-600 text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">MongoDB</h3>
                <p className="text-gray-600 text-sm">
                  Advanced schema design, indexing strategies, aggregation pipelines, and performance optimization for enterprise data needs.
                </p>
              </div>

              {/* Express.js */}
              <div className="bg-gradient-to-br from-green-50 to-cyan-50 rounded-2xl p-6 border border-green-100 card-hover">
                <div className="w-16 h-16 rounded-2xl bg-green-100 flex items-center justify-center mb-4 shadow-sm">
                  <i className="fas fa-server text-green-600 text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">Express.js</h3>
                <p className="text-gray-600 text-sm">
                  Structured API development with middleware architecture, authentication systems, and RESTful best practices.
                </p>
              </div>

              {/* React */}
              <div className="bg-gradient-to-br from-cyan-50 to-green-50 rounded-2xl p-6 border border-cyan-100 card-hover">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-100 to-green-100 flex items-center justify-center mb-4 shadow-sm">
                  <i className="fab fa-react text-cyan-600 text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">React</h3>
                <p className="text-gray-600 text-sm">
                  Component architecture, state management solutions, performance optimization, and responsive UI development.
                </p>
              </div>

              {/* Node.js */}
              <div className="bg-gradient-to-br from-green-50 to-cyan-50 rounded-2xl p-6 border border-green-100 card-hover">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-r from-cyan-100 to-green-100 flex items-center justify-center mb-4 shadow-sm">
                  <i className="fab fa-node-js text-green-600 text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">Node.js</h3>
                <p className="text-gray-600 text-sm">
                  Scalable backend systems, event-driven architecture, microservices, and real-time applications.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Capabilities Section */}
      <section className="py-2 px-4 bg-gradient-to-r from-cyan-50 to-green-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-5">Core Technical Capabilities</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Left Column */}
            <div className="space-y-4">
              {/* Responsive UI Design */}
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-cyan-100 card-hover">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-semibold text-gray-800 flex items-center">
                    <i className="fas fa-mobile-alt text-cyan-500 mr-2"></i>
                    Responsive UI Design
                  </span>
                  <span className="font-bold text-cyan-600">85%</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-progress bg-gradient-to-r from-cyan-500 to-cyan-600" style={{ width: '85%' }}></div>
                </div>
              </div>

              {/* Database Optimization */}
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-green-100 card-hover">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-semibold text-gray-800 flex items-center">
                    <i className="fas fa-database text-green-500 mr-2"></i>
                    Database Optimization
                  </span>
                  <span className="font-bold text-green-600">90%</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-progress bg-gradient-to-r from-green-500 to-green-600" style={{ width: '90%' }}></div>
                </div>
              </div>

              {/* API Architecture */}
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-cyan-100 card-hover">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-semibold text-gray-800 flex items-center">
                    <i className="fas fa-code text-cyan-500 mr-2"></i>
                    API Architecture
                  </span>
                  <span className="font-bold text-cyan-600">92%</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-progress bg-gradient-to-r from-cyan-500 to-cyan-600" style={{ width: '92%' }}></div>
                </div>
              </div>

              {/* DevOps & CI/CD */}
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-green-100 card-hover">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-semibold text-gray-800 flex items-center">
                    <i className="fas fa-cogs text-green-500 mr-2"></i>
                    DevOps & CI/CD
                  </span>
                  <span className="font-bold text-green-600">83%</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-progress bg-gradient-to-r from-green-500 to-green-600" style={{ width: '83%' }}></div>
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-4">
              {/* Cloud Deployment */}
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-green-100 card-hover">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-semibold text-gray-800 flex items-center">
                    <i className="fas fa-cloud text-green-500 mr-2"></i>
                    Cloud Deployment
                  </span>
                  <span className="font-bold text-green-600">88%</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-progress bg-gradient-to-r from-green-500 to-green-600" style={{ width: '88%' }}></div>
                </div>
              </div>

              {/* Testing & QA */}
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-cyan-100 card-hover">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-semibold text-gray-800 flex items-center">
                    <i className="fas fa-vial text-cyan-500 mr-2"></i>
                    Testing & QA
                  </span>
                  <span className="font-bold text-cyan-600">86%</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-progress bg-gradient-to-r from-cyan-500 to-cyan-600" style={{ width: '86%' }}></div>
                </div>
              </div>

              {/* Security Standards */}
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-green-100 card-hover">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-semibold text-gray-800 flex items-center">
                    <i className="fas fa-shield-alt text-green-500 mr-2"></i>
                    Security Standards
                  </span>
                  <span className="font-bold text-green-600">84%</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-progress bg-gradient-to-r from-green-500 to-green-600" style={{ width: '84%' }}></div>
                </div>
              </div>

              {/* Performance Optimization */}
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-cyan-100 card-hover">
                <div className="flex justify-between items-center mb-3">
                  <span className="font-semibold text-gray-800 flex items-center">
                    <i className="fas fa-tachometer-alt text-cyan-500 mr-2"></i>
                    Performance Optimization
                  </span>
                  <span className="font-bold text-cyan-600">91%</span>
                </div>
                <div className="skill-bar">
                  <div className="skill-progress bg-gradient-to-r from-cyan-500 to-cyan-600" style={{ width: '91%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Additional Technologies */}
      <section className="py-5 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="bg-white rounded-3xl shadow-xl p-8 card-hover border-t-4 border-green-500">
            <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">Additional Technologies</h2>
            <p className="text-gray-600 text-center mb-8 max-w-2xl mx-auto">
              We complement our core MERN expertise with a wide range of modern tools and technologies to deliver comprehensive solutions.
            </p>
            
            <div className="flex flex-wrap justify-center gap-3 mb-8">
              <div className="tech-tag bg-gradient-to-r from-cyan-50 to-white border-cyan-200">
                <i className="fab fa-microsoft text-cyan-600 mr-2"></i>
                TypeScript
              </div>
              <div className="tech-tag bg-gradient-to-r from-green-50 to-white border-green-200">
                <i className="fab fa-aws text-green-600 mr-2"></i>
                AWS
              </div>
              <div className="tech-tag bg-gradient-to-r from-cyan-50 to-white border-cyan-200">
                <i className="fab fa-docker text-cyan-600 mr-2"></i>
                Docker
              </div>
              <div className="tech-tag bg-gradient-to-r from-green-50 to-white border-green-200">
                <i className="fas fa-project-diagram text-green-600 mr-2"></i>
                GraphQL
              </div>
              <div className="tech-tag bg-gradient-to-r from-cyan-50 to-white border-cyan-200">
                <i className="fas fa-cube text-cyan-600 mr-2"></i>
                Rebar
              </div>
              <div className="tech-tag bg-gradient-to-r from-green-50 to-white border-green-200">
                <i className="fab fa-react text-green-600 mr-2"></i>
                Next.js
              </div>
              <div className="tech-tag bg-gradient-to-r from-cyan-50 to-white border-cyan-200">
                <i className="fas fa-bolt text-cyan-600 mr-2"></i>
                Fast API
              </div>
              <div className="tech-tag bg-gradient-to-r from-green-50 to-white border-green-200">
                <i className="fas fa-fire text-green-600 mr-2"></i>
                Firebase
              </div>
              <div className="tech-tag bg-gradient-to-r from-cyan-50 to-white border-cyan-200">
                <i className="fab fa-css3-alt text-cyan-600 mr-2"></i>
                Tailwind CSS
              </div>
              <div className="tech-tag bg-gradient-to-r from-green-50 to-white border-green-200">
                <i className="fab fa-git-alt text-green-600 mr-2"></i>
                Git
              </div>
              <div className="tech-tag bg-gradient-to-r from-cyan-50 to-white border-cyan-200">
                <i className="fas fa-database text-cyan-600 mr-2"></i>
                PostgreSQL
              </div>
              <div className="tech-tag bg-gradient-to-r from-green-50 to-white border-green-200">
                <i className="fas fa-chart-bar text-green-600 mr-2"></i>
                Data Analytics
              </div>
            </div>

            {/* CTA Section */}
            <div className="text-center">
              <a href='/Propasal.pdf' download className="w-60  md:80 bg-gradient-to-r from-cyan-600 to-green-500 text-white font-semibold py-4 px-8 rounded-xl hover:from-cyan-700 hover:to-green-600 transition-all duration-300 flex items-center justify-center mx-auto shadow-lg hover:shadow-xl hover:scale-[1.02]">
                <i className="fas fa-file-alt mr-3"></i>
                Technical Documentation
              </a>
              
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
     
    </div>
  );
};

export default Technical;