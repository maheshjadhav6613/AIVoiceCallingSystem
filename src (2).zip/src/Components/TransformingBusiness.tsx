import React from 'react';

const TransformingBusiness: React.FC = () => {




  const handleWhatsAppClick = () => {
    const whatsappNumber = "919146677505";
    const defaultMessage = encodeURIComponent("Hello! I'm interested in your MERN stack development services. Schedule a Strategy Session");
    
    window.open(`https://wa.me/${whatsappNumber}?text=${defaultMessage}`, '_blank');
  };

  const handleCallClick = () => {
    window.location.href = 'tel:+919146677505';
  };






  return (
    <div className="min-h-screen bg-white">
      <style>{`
        .card-hover {
          transition: all 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }
        .cyan-gradient-text {
          background: linear-gradient(90deg, #06b6d4, #0891b2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .green-gradient-text {
          background: linear-gradient(90deg, #22c55e, #16a34a);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        .cyan-to-green-gradient {
          background: linear-gradient(90deg, #06b6d4, #22c55e);
        }
      `}</style>

      {/* Header Section */}
      <section className="pt-12 pb-5 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="inline-flex items-center px-5 py-3 rounded-full bg-white shadow-lg border border-cyan-100 mb-3">
            <i className="fas fa-lightbulb text-green-500 mr-2"></i>
            <span className="text-cyan-700 ">TRANSFORMING BUSINESS CHALLENGES</span>
          </div>
          <h1 className="text-4xl md:text-4xl font-bold text-gray-800 mb-3 leading-tight">
            From Challenges to  
            <span className="cyan-gradient-text"> Strategic Solutions</span>
          </h1>
          <p className="text-sm text-gray-600 max-w-3xl mx-auto leading-relaxed">
            We analyze your requirements and engineer strategic solutions that deliver measurable business outcomes.
          </p>
        </div>
      </section>

      {/* Challenges Section */}
      <section className="py-2 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Common Business Challenges We Solve</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Challenge 01 */}
            <div className="bg-white rounded-2xl shadow-lg challenge-card border-l-red-500 p-8 card-hover">
              <div className="flex items-start mb-6">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center mr-4">
                  <span className="text-red-700 font-bold text-xl">01</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-800">Legacy Systems & Technical Debt</h3>
              </div>
              <p className="text-gray-600 leading-relaxed">
                Outdated architectures and code create maintenance nightmares, security vulnerabilities, and limit business agility.
              </p>
              <div className="mt-6 flex items-center text-red-600">
                <i className="fas fa-exclamation-triangle mr-2"></i>
                <span className="text-sm font-medium">High Risk Challenge</span>
              </div>
            </div>

            {/* Challenge 02 */}
            <div className="bg-white rounded-2xl shadow-lg challenge-card border-l-orange-500 p-8 card-hover">
              <div className="flex items-start mb-6">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center mr-4">
                  <span className="text-orange-700 font-bold text-xl">02</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-800">Scalability & Performance Issues</h3>
              </div>
              <p className="text-gray-600 leading-relaxed">
                Growing businesses face bottlenecks with systems that can't scale, resulting in slow load times and poor user experiences.
              </p>
              <div className="mt-6 flex items-center text-orange-600">
                <i className="fas fa-tachometer-alt mr-2"></i>
                <span className="text-sm font-medium">Performance Critical</span>
              </div>
            </div>

            {/* Challenge 03 */}
            <div className="bg-white rounded-2xl shadow-lg challenge-card border-l-purple-500 p-8 card-hover">
              <div className="flex items-start mb-6">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center mr-4">
                  <span className="text-purple-700 font-bold text-xl">03</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-800">Digital Transformation Challenges</h3>
              </div>
              <p className="text-gray-600 leading-relaxed">
                Enterprises struggle to modernize operations while maintaining business continuity, often lacking technical expertise.
              </p>
              <div className="mt-6 flex items-center text-purple-600">
                <i className="fas fa-sync-alt mr-2"></i>
                <span className="text-sm font-medium">Transformation Needed</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Solutions Section */}
      <section className="py-5 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text&nbsp; text-4xl font-bold text-center text-gray-800 mb-4">Our Strategic Solutions</h2>
          <p className="text-xl text-gray-600 text-center mb-12 max-w-3xl mx-auto">
            Engineered solutions that transform business challenges into competitive advantages
          </p>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Solution 04 */}
            <div className="bg-white rounded-2xl shadow-xl solution-card overflow-hidden card-hover border-t-4 border-cyan-500">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-14 h-14 rounded-2xl bg-cyan-100 flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-archway text-cyan-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800">MERN Architecture Modernization</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  We rebuild legacy systems with modern MERN stack architecture, creating maintainable, secure, and scalable applications.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center benefit-item">
                    <i className="fas fa-check-circle text-cyan-600 mr-3"></i>
                    <span className="text-gray-700 font-medium">Reduced Maintenance</span>
                  </div>
                  <div className="flex items-center benefit-item">
                    <i className="fas fa-check-circle text-cyan-600 mr-3"></i>
                    <span className="text-gray-700 font-medium">Enhanced Security</span>
                  </div>
                  <div className="flex items-center benefit-item">
                    <i className="fas fa-check-circle text-cyan-600 mr-3"></i>
                    <span className="text-gray-700 font-medium">Future-proofing</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Solution 05 */}
            <div className="bg-white rounded-2xl shadow-xl solution-card overflow-hidden card-hover border-t-4 border-green-500">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-14 h-14 rounded-2xl bg-green-100 flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-cloud text-green-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800">Scalable Cloud Architecture</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  We engineer cloud-native applications with distributed architectures and automatic scaling to handle any workload.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center benefit-item">
                    <i className="fas fa-check-circle text-green-500 mr-3"></i>
                    <span className="text-gray-700 font-medium">Load Balancing</span>
                  </div>
                  <div className="flex items-center benefit-item">
                    <i className="fas fa-check-circle text-green-500 mr-3"></i>
                    <span className="text-gray-700 font-medium">Auto-scaling</span>
                  </div>
                  <div className="flex items-center benefit-item">
                    <i className="fas fa-check-circle text-green-500 mr-3"></i>
                    <span className="text-gray-700 font-medium">Global CDN</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Solution 06 */}
            <div className="bg-white rounded-2xl shadow-xl solution-card overflow-hidden card-hover border-t-4 border-cyan-500">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-100 to-green-100 flex items-center justify-center mr-4 shadow-sm">
                    <i className="fas fa-chess-knight text-cyan-600 text-xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800">Strategic Digital Transformation</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  We provide end-to-end transformation with phased implementation to minimize disruption while maximizing business value.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center benefit-item">
                    <i className="fas fa-check-circle text-cyan-600 mr-3"></i>
                    <span className="text-gray-700 font-medium">Seamless Migration</span>
                  </div>
                  <div className="flex items-center benefit-item">
                    <i className="fas fa-check-circle text-cyan-600 mr-3"></i>
                    <span className="text-gray-700 font-medium">Process Optimization</span>
                  </div>
                  <div className="flex items-center benefit-item">
                    <i className="fas fa-check-circle text-cyan-600 mr-3"></i>
                    <span className="text-gray-700 font-medium">Training Support</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="text-center mt-5">
            <button onClick={handleWhatsAppClick} className="bg-gradient-to-r from-cyan-600 to-green-500 text-white font-semibold py-4 px-12 rounded-xl hover:from-cyan-700 hover:to-green-600 transition-all duration-300 flex items-center justify-center mx-auto shadow-lg hover:shadow-xl text-lg hover:scale-[1.02]">
              <i className="fas fa-calendar-check mr-3"></i>
              Schedule a Strategy Session
            </button>
           
          </div>
        </div>
      </section>

    
    </div>
  );
};

export default TransformingBusiness;