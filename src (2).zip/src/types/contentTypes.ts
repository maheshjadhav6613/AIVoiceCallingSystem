export interface ContentData {
  _id?: string;
  // Hero Section
  heroTitle: string;
  heroTitleColor: string;
  heroBgColor: string;

  // Statistics Section
  yearsExperience: number;
  yearsExperienceText: string;
  teamMembers: number;
  teamMembersText: string;
  projectsCompleted: number;
  projectsCompletedText: string;
  clientSatisfaction: number;
  clientSatisfactionText: string;
  supportAvailable: string;
  supportAvailableText: string;
  industryAwards: number;
  industryAwardsText: string;

  // Project Range
  projectRange: string;
  projectRangeText: string;

  // Global Presence
  globalPresence: string;
  globalPresenceText: string;

  // Consultation Section
  consultationButtonText: string;
  consultationButtonColor: string;

  // Excellence Section
  yearsExcellence: number;
  yearsExcellenceText: string;
  excellenceDescription: string;

  // Premium Solutions Section
  premiumSolutionsTitle: string;
  premiumSolutionsDescription: string;

  // Images (store image URLs after upload)
  heroImage: string;
  premiumSolutionImage: string;

  // Section background colors
  statisticsBgColor: string;
  projectRangeBgColor: string;
  globalPresenceBgColor: string;
  excellenceBgColor: string;
  premiumSolutionsBgColor: string;

  // Text colors for sections
  statisticsTextColor: string;
  projectRangeTextColor: string;
  globalPresenceTextColor: string;
  excellenceTextColor: string;
  premiumSolutionsTextColor: string;

  // Icons (you can store icon names or URLs)
  statisticsIcon: string;
  teamIcon: string;
  projectIcon: string;
  satisfactionIcon: string;
  supportIcon: string;
  awardIcon: string;
}

export const defaultContent: ContentData = {
  // Hero Section
  heroTitle: "Enterprise-Level Web Development",
  heroTitleColor: "#000000",
  heroBgColor: "#ffffff",

  // Statistics Section
  yearsExperience: 7,
  yearsExperienceText: "Years Experience",
  teamMembers: 23,
  teamMembersText: "Team Members",
  projectsCompleted: 500,
  projectsCompletedText: "Projects Completed",
  clientSatisfaction: 98,
  clientSatisfactionText: "Client Satisfaction",
  supportAvailable: "24/8",
  supportAvailableText: "Support Available",
  industryAwards: 25,
  industryAwardsText: "Industry Awards",

  // Project Range
  projectRange: "From 20,000 to 45,00,000",
  projectRangeText: "Project Range",

  // Global Presence
  globalPresence: "India, Dubai, Singapore & UK",
  globalPresenceText: "Global Presence",

  // Consultation Section
  consultationButtonText: "Book a Consultation",
  consultationButtonColor: "#007bff",

  // Excellence Section
  yearsExcellence: 9,
  yearsExcellenceText: "Years of Excellence",
  excellenceDescription: "Delivering exceptional results",

  // Premium Solutions Section
  premiumSolutionsTitle: "Premium Web Solutions",
  premiumSolutionsDescription: "Your professional image would be displayed here in the actual implementation",

  // Images
  heroImage: "",
  premiumSolutionImage: "",

  // Section background colors
  statisticsBgColor: "#f8f9fa",
  projectRangeBgColor: "#ffffff",
  globalPresenceBgColor: "#f8f9fa",
  excellenceBgColor: "#ffffff",
  premiumSolutionsBgColor: "#f8f9fa",

  // Text colors for sections
  statisticsTextColor: "#000000",
  projectRangeTextColor: "#000000",
  globalPresenceTextColor: "#000000",
  excellenceTextColor: "#000000",
  premiumSolutionsTextColor: "#000000",

  // Icons
  statisticsIcon: "fa-chart-line",
  teamIcon: "fa-users",
  projectIcon: "fa-briefcase",
  satisfactionIcon: "fa-smile",
  supportIcon: "fa-headset",
  awardIcon: "fa-trophy",
};